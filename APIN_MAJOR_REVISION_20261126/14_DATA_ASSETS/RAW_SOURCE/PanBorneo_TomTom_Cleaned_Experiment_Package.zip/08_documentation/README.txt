# Pan Borneo TomTom Cleaned Experiment Package

Generated: 2026-06-23 03:55:31

## Cleaning principle
- Original uploaded data are preserved unchanged in `00_raw_original/`.
- Date-fixed CSV source is preserved unchanged in `01_source_fixed_dates_csv/` and used as input for cleaning.
- Cleaned outputs are written into new folders. No raw CSV file was overwritten.

## Main summary
- Valid cleaned records: 244,477 from 83 CSV files.
- Stable nodes: 51.
- Time range: 2025-12-08 13:15:00 to 2026-02-28 23:45:00.
- Main model input: `05_features/features_panel_1h.csv.gz`.
- Sensitivity input: `05_features/features_panel_30min.csv.gz`.
- 15min observed-only reference: `04_panels/panel_15min_observed_only.csv.gz`.

## Important evaluation rule
Use `valid_target == 1` for model training/evaluation targets. The `*_input` columns are filled for model input continuity only. Do not evaluate model error on imputed target rows.
