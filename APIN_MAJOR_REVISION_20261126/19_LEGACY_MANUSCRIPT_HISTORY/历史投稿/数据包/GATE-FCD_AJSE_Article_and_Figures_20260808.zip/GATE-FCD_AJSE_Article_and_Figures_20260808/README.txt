GATE-FCD AJSE manuscript and figure package
Date: 2026-08-08

Contents
--------
Manuscript/
  GATE-FCD_AJSE_Manuscript_20260808.docx

Figures/
  Figure1_Study_Corridor_and_FCD_Node_Distribution.png
  Figure2_FCD_Temporal_Availability_and_Spatiotemporal_Characteristics.png
  Figure3_GATE-FCD_Overall_Architecture.png
  Figure4_GATE-FCD_Operational_Implementation.png
  Figure5_Multi-Horizon_Performance_and_Stability.png
  Figure6_Reliability_and_Spatial_Error_Boundaries.png
  Figure7_Statistical_Evidence_Boundaries.png

The seven PNG files were extracted directly from the final manuscript DOCX so that the standalone figure files match the images embedded in the article.
