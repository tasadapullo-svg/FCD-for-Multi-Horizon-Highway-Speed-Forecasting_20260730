# Fig. A/B/C current-data package

Generated from AJSE_Fig_ABC_Daily_Data_20260806.xlsx after benchmark-data recheck.
The figure follows the provided three-panel style. Because the current dataset is the PanBorneo benchmark hourly panel, the plot uses node-hour records.

Key point: 2026-02-17 has 0 raw observed node-hour records, 1,224 raw missing records, and 1,224 benchmark-input records after causal LOCF filling.
