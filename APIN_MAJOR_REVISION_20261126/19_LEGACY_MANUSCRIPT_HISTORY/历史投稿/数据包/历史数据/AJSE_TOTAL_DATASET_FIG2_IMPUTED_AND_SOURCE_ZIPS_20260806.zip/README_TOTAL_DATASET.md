﻿# AJSE total dataset package, 2026-08-06

This total dataset zip contains the three source zip packages provided by the user plus the Fig. 2 weekday-slot imputed result package generated on 2026-08-06.

Files are stored as nested zip archives to preserve the original package boundaries. See PACKAGE_INVENTORY_SHA256.csv for source paths, byte sizes, and SHA256 hashes.
