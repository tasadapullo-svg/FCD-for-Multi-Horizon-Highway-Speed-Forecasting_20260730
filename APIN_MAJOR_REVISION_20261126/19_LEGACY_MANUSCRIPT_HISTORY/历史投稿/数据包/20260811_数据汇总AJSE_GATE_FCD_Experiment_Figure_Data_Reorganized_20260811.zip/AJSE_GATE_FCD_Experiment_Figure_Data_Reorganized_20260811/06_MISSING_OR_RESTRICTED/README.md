# Missing / restricted source materials

Not embedded in this reconstructed ZIP:
1. Raw provider FCD records and time-resolved restricted speed panels.
2. Precise node coordinates.
3. Original prediction Parquets and neural/model checkpoints.
4. Secrets, API credentials, environment files, and source training workspaces.
5. Byte-for-byte copies of File Library referenced ZIP/XLSX/PNG artifacts (File Library references are not mounted as local files in this runtime).
6. Final Figure 5 derived-data package, because it was not surfaced by the current File Library search.
7. Figure 2 panel (d) full spatiotemporal speed-anomaly matrix, because it was not surfaced as a retrievable tabular source in this session.

This archive intentionally avoids fabricating missing source rows or reconstructing restricted raw observations.
