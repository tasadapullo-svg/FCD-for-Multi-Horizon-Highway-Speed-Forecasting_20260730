# Formal scope and exclusions

PRIMARY FORMAL SOURCE: AJSE Phase 2A-1 only.

Do not merge these into formal primary results:
- CRG-TCN
- old Phase 13/15/P6/P7/P8 outputs
- contaminated “final-week” winner claims
- alternative point-ahead targets from other projects
- rainfall/environment-aware forecasting experiments
- 42-node monitoring-study availability statistics

Current target semantics:
- H1: future 1-hour window mean; 1/1 valid
- H3: future 3-hour window mean; 3/3 valid
- H6: future 6-hour window mean; >=5/6 valid (6/6 sensitivity)

Current primary inference:
- independent unit = rolling-origin fold, n=6
- five pre-specified comparisons per horizon
- Holm adjustment within horizon
- significant-after-Holm = 0
- cluster bootstrap = supplementary
