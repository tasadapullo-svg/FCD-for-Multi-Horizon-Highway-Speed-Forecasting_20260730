# Data dictionary (archive-level)

## Core identifiers
- fold: rolling-origin fold 1–6.
- horizon: future-window horizon, H1/H3/H6.
- model: HA, SeasonalHA, Persistence, Ridge, XGBoost, or GRU.
- seed: 42 for deterministic runs; 42/2026/3407 for XGBoost and GRU.

## Error metrics
- MAE_km_h: mean absolute error in km/h.
- fold_SD: sample standard deviation of six fold-level MAEs.
- delta_MAE_model_minus_SeasonalHA: model mean MAE minus SeasonalHA mean MAE; negative favors the model.

## Statistical inference
- estimate_A_minus_B: MAE_A − MAE_B; negative favors model A.
- CI_lower / CI_upper: reported interval bounds from the source statistical output.
- holm_adjusted_p: multiplicity-adjusted p-value within horizon.
- significant_after_holm: all False in the formal 15-row primary table.
- inference_role=supplementary: cluster bootstrap is supportive, not the primary independent-unit inference.

## Figure 2 availability
- expected_records: theoretical node×15-min slots for that date.
- observed_records: returned platform records (eligible + quality-ineligible).
- missing_records: expected − observed.
- eligible_records: records passing frozen record-level quality rules.
- quality_ineligible_records: returned records failing quality rules.
- availability_rate: observed / expected.
