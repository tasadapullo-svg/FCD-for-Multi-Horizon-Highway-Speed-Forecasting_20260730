# AJSE GATE-FCD Experiment & Figure Data — Reorganized Archive (2026-08-11)

## Purpose
This archive reorganizes the experiment protocol, formal Phase 2A-1 results/audits, and figure-support data recoverable from the Arabian Journal for Science and Engineering project dialogue and File Library.

## Formal evidence rule
Only Phase 2A-1 retrospective rolling-origin evidence is treated as formal primary evidence in this archive.

Included formal scope:
- 51 fixed virtual FCD nodes
- H1/H3/H6 future-window mean-speed targets
- six rolling-origin folds
- HA, SeasonalHA, Persistence, Ridge, XGBoost, GRU
- 18 common fold×horizon manifests
- 180/180 completed formal runs
- 92,147 test-manifest records
- 20/20 leakage assertions passed
- fold-level primary inference with Holm correction
- day×spatial-block cluster bootstrap as supplementary evidence

Excluded from formal scope:
- CRG-TCN and old P6/P7/P8 branches
- Phase 13/15 legacy comparisons
- any claim that Fold 6 is an independent blind test
- older 42-node/PLOS monitoring availability metrics
- outdated 403,665 / 100,980 theoretical-slot convention
- raw restricted FCD records, model checkpoints, secrets, and source training workspaces

## Figure-data status
- Figure 1: latest manuscript summary statistics included; precise coordinates and the original binary image are not copied into this reconstructed archive.
- Figure 2: 83-day daily availability/missing/observed/eligible source data included for panels (a)–(c).
- Figure 3: fold timeline and audit summary included.
- Figure 4: complete 18 summary rows, 108 fold rows, 36 seed-summary rows included and cross-validated.
- Figure 5: derivation specification was found, but final derived data were not surfaced by File Library search; no values are fabricated.
- Figure 6: 15 fold-primary + 15 cluster-supplementary comparisons and a reconstructed horizon-aware engineering matrix included.

## Important interpretation boundaries
- FCD speed is provider-derived, not independent ground truth.
- H6 often has lower MAE partly because its target is a longer future-window average and therefore smoother; this does not mean longer-horizon forecasting is inherently easier.
- XGBoost has the lowest descriptive mean MAE at H1/H3/H6 in the validated Figure 4 dataset, but zero pre-specified fold-level comparisons remained significant after Holm correction.
- Fold 6 is a previously exposed historical period and cannot be described as an independent blind final test.

## Reconstruction note
File Library items are references, not mounted binary files. This ZIP therefore contains reconstructed/tabulated data and provenance, not byte-for-byte copies of every earlier ZIP/XLSX/PNG. Where exact source data could not be recovered from the current File Library search, the archive marks the gap explicitly.
