# Figure 5 data status

The File Library search surfaced the frozen Figure 5 derivation/audit specification, but did not surface the completed derived-data package or its CSV/XLSX outputs in this session.

Therefore this reconstructed archive DOES NOT invent:
- reliability-bin MAE values,
- node-by-fold MAE heatmap cells,
- node risk profiles,
- corridor error-profile values,
- final Figure 5 render.

Expected derived outputs from the project specification included reliability-conditioned out-of-fold errors, node-by-fold MAE for XGBoost, and an out-of-fold error profile along the verified node sequence.

Status: DERIVED_RESULT_NOT_FOUND_IN_CURRENT_FILE_LIBRARY_SEARCH.
Action: if the original Fig05_COMPLETE_RESULT_PACKAGE.zip is later uploaded/located, merge it as a separate source-preserving subfolder and verify hashes before use.
