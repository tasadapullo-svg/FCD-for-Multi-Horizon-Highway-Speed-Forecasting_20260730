# AJSE GATE-FCD — Final Clean Canonical Data Package (2026-08-11)

## Purpose
This package is the cleaned consolidation of the Arabian Journal for Science and Engineering GATE-FCD project data available in the project dialogue and File Library.

## Canonical rule
Primary evidence is restricted to the formal AJSE Phase 2A-1 retrospective rolling-origin evaluation and the latest 2026-08-08 manuscript conventions.

## Current core totals
- 51 fixed FCD nodes
- approximately 130 km corridor
- 403,512 theoretical node×15-min slots
- 242,757 observed returned slots
- 160,755 missing/unreturned slots
- 241,601 quality-eligible slots
- 1,156 observed but quality-ineligible records
- 100,878 theoretical node×hour slots
- 18 common fold×horizon manifests
- 1,053,618 manifest records (overlapping expanding-window records, not independent n)
- 92,147 test-manifest records
- 180/180 formal runs; 0 failed
- 20/20 leakage assertions passed
- 0/15 Holm-significant pre-specified comparisons

## Current figure numbering
1. Corridor / FCD nodes
2. Temporal availability / spatiotemporal observations
3. Overall GATE-FCD architecture
4. Eligibility, causal targets and rolling-origin implementation
5. Multi-horizon performance and temporal/seed stability
6. Reliability-conditioned and spatial error boundaries
7. Statistical evidence boundaries

## Important removed data
Old 403,665 / 242,883 / 100,980 or 100,929 conventions, 97.30% monitoring-study availability, 42-node versions, CRG-TCN and legacy Phase13/15/P6-P8 results, pre-freeze diagrams with 2025-12-01 start or “10 models”, independent-blind-test wording, ground-truth wording, unaudited runtime superiority, and unsupported sensitivity numbers are not canonical.

## Unresolved conflict
The latest 2026-08-08 manuscript reports H3 mean node P90 absolute error as approximately 2.99 km/h, while an earlier 2026-08-07 figure text shows approximately 2.09 km/h. The underlying final derived source table was not located in the current File Library search. Therefore the canonical Figure 6 summary intentionally leaves that value blank/withheld.

## Interpretation
XGBoost has the lowest descriptive fold-macro mean MAE at H1/H3/H6, SeasonalHA remains close, and Persistence is competitive at H1 but degrades at H3/H6. These are descriptive findings. No pre-specified comparison remained significant after Holm adjustment, so universal statistical-superiority claims are not supported.
