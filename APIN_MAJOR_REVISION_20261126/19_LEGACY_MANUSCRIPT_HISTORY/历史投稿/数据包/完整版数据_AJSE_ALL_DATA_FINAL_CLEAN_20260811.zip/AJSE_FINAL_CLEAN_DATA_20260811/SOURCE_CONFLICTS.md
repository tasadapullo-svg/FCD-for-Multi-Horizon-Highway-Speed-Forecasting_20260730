# Source Conflict Register

## Figure 6 H3 mean node P90 absolute error
- Earlier 2026-08-07 figure text: approximately 2.09 km/h.
- Latest 2026-08-08 manuscript: approximately 2.99 km/h.
- Final derived node-risk/source table: not located in the current File Library search.
- Canonical action: WITHHOLD the H3 mean-P90 numeric value until the source table is recovered and recomputed.

This is the only numeric conflict intentionally left unresolved in the cleaned package.
