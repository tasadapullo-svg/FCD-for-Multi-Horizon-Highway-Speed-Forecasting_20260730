# AJSE Fig. 2 weekday-slot imputed data package

Created: 2026-08-06T13:49:12

## Imputation rule

For each non-quality-eligible 15-minute node slot, this package fills `speed_15min_filled`, `travel_time_15min_filled`, and `confidence_15min_filled` using the mean of quality-eligible observations with the same:

1. `node_id`
2. weekday (`Monday` ... `Sunday`)
3. 15-minute clock slot (`HH:MM`)

Example: the corridor-wide blank day `2026-02-17 00:00-23:45` is a Tuesday, so each node-slot is filled from that node's other Tuesday observations at the same time of day.

## Key counts

- Theoretical 15-minute node slots: 403,512
- Original quality-eligible observations retained: 241,601
- Non-quality-eligible slots filled in the full panel: 161,911
- Missing/unreturned slots from the official missing package: 160,755
- Observed but quality-ineligible slots from the official missing package: 1,156
- Fig. 2(a) exact missing slots preserved: 429
- Fig. 2(a) exact quality-ineligible slots preserved: 19

## Important boundary

The frozen eligible parquet contains only quality-eligible observations. The uploaded missing-data package gives exact full-period counts by node-date, but not exact full-period timestamps for all 1,156 quality-ineligible slots. Therefore:

- All exact non-quality-eligible timestamps are filled.
- Fig. 2(a) exact missing/quality-ineligible labels are preserved.
- Outside Fig. 2(a), unresolved non-eligible timestamps are labeled `noneligible_mixed_missing_or_quality_by_node_date` when that node-date has quality-ineligible counts.
- The node-date accounting file preserves the official 160,755 / 1,156 separation.
- 24 slots had no same-node reference mean and were filled using the explicitly marked corridor-level same-weekday same-slot fallback.

## Main files

- `02_IMPUTED_FULL_PANEL/fig2_full_15min_panel_weekday_slot_imputed.parquet`
- `02_IMPUTED_FULL_PANEL/fig2_full_15min_panel_weekday_slot_imputed.csv.gz`
- `02_IMPUTED_FULL_PANEL/fig2_all_noneligible_slots_imputed_values.parquet`
- `02_IMPUTED_FULL_PANEL/fig2_imputation_reference_means_by_node_weekday_slot.csv`
- `02_IMPUTED_FULL_PANEL/fig2_imputation_reference_means_by_corridor_weekday_slot_fallback.csv`
- `03_FIG2_DERIVED_TABLES/fig02a_grid_state_slice_weekday_slot_imputed.csv`
- `03_FIG2_DERIVED_TABLES/fig02c_node_day_coverage_after_weekday_slot_imputation.csv`
- `04_QA/qa_checks.json`
- `04_QA/missing_quality_accounting_by_node_date.csv`

## Three-round QA

1. Count/accounting check against the official missing package.
2. Formula recalculation and blank-day fill check.
3. Written parquet reload plus zip readback.

## QA summary

[
  {
    "check": "grid_and_core_counts",
    "status": "PASS",
    "observed": {
      "theoretical_keys": 403512,
      "eligible_keys": 241601,
      "noneligible_slots_filled": 161911
    },
    "expected": {
      "theoretical_keys": 403512,
      "eligible_keys": 241601,
      "missing_unreturned_slots_summary": 160755,
      "quality_ineligible_slots_summary": 1156,
      "noneligible_slots_filled": 161911,
      "fig2a_exact_missing": 429,
      "fig2a_exact_quality_ineligible": 19,
      "corridor_wide_full_day_outage_date": "2026-02-17",
      "corridor_wide_full_day_outage_filled_slots": 4896
    }
  },
  {
    "check": "node_date_accounting_matches_missing_package",
    "status": "PASS",
    "max_abs_difference": 0,
    "rows_checked": 4233
  },
  {
    "check": "corridor_wide_outage_2026_02_17_filled",
    "status": "PASS",
    "filled_slots": 4896,
    "unique_nodes": 51,
    "min_basis_n": 1,
    "fallback_slots": 24
  },
  {
    "check": "fig2a_exact_state_counts_preserved",
    "status": "PASS",
    "fig2a_missing_exact": 429,
    "fig2a_quality_exact": 19,
    "fig2a_rows": 768
  },
  {
    "check": "no_nulls_after_imputation",
    "status": "PASS",
    "null_counts": {
      "speed_15min_filled": 0,
      "travel_time_15min_filled": 0,
      "confidence_15min_filled": 0
    }
  },
  {
    "check": "independent_reload_written_panel",
    "status": "PASS",
    "rows_reloaded": 403512,
    "imputed_rows_reloaded": 161911
  },
  {
    "check": "independent_formula_recalculation",
    "status": "PASS",
    "max_abs_differences": {
      "speed": 0.0,
      "travel_time": 0.0,
      "confidence": 0.0
    },
    "node_scope_imputed_slots": 161887,
    "corridor_fallback_imputed_slots": 24
  }
]
