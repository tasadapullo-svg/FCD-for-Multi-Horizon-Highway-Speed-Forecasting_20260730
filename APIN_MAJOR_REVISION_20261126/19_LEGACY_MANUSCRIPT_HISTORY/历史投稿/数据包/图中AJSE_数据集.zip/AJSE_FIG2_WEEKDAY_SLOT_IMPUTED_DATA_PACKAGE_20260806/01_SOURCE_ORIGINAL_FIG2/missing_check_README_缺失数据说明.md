# Fig. 2 Missing-Data Check

## What can be located exactly from the uploaded package

1. Full study period: missing counts are exact at **node × date** resolution.
2. Fig. 2(a) 24-hour excerpt: every missing 15-min timestamp is exact.
3. The full-study package does **not** contain the 242,757 observed node–timestamp keys,
   so all 160,755 exact missing timestamps cannot be reconstructed from the uploaded
   aggregate files alone.

## Frozen totals

- Theoretical 15-min slots: 403,512
- Eligible slots: 241,601
- Missing / unreturned slots: 160,755
- Observed but quality-ineligible slots: 1,156
- Fig. 2(a) exact missing timestamps: 429
- Fig. 2(a) exact quality-ineligible timestamps: 19

## Highest-priority dates

| Rank | Date | Missing/unreturned slots | Missing rate | Fully missing nodes |
|---:|---|---:|---:|---:|
| 1 | 2026-02-17 | 4,896 | 100.00% | 51 |
| 2 | 2026-02-12 | 3,048 | 62.25% | 0 |
| 3 | 2026-02-11 | 2,922 | 59.68% | 0 |
| 4 | 2026-01-25 | 2,881 | 58.84% | 0 |
| 5 | 2026-02-18 | 2,881 | 58.84% | 0 |
| 6 | 2026-02-22 | 2,881 | 58.84% | 0 |
| 7 | 2026-01-17 | 2,880 | 58.82% | 0 |
| 8 | 2026-01-20 | 2,880 | 58.82% | 0 |
| 9 | 2026-01-22 | 2,880 | 58.82% | 0 |
| 10 | 2026-02-13 | 2,880 | 58.82% | 0 |

The corridor-wide full-day outage in the packaged data is **2026-02-17**:
all 51 nodes × 96 quarter-hours = 4,896 missing/unreturned slots.

## Important distinction

- `missing_unreturned_slots`: no observed node–timestamp key exists.
- `observed_quality_ineligible_slots`: a row exists, but it fails the frozen quality contract.
- Do not combine these categories when searching the original data.

## Before “filling” the data

Do not interpolate these slots and then retain the existing paper results. Adding recovered
observations changes:

- eligible 15-min coverage;
- 2-of-4 hourly eligibility;
- causal histories and imputation flags;
- H1/H3/H6 target eligibility;
- all sample manifests, model predictions, metrics, and figures.

Only restore a slot if a genuine contemporaneous raw provider record exists in the archived
raw logs. After restoration, rebuild the pipeline and rerun all affected experiments.
