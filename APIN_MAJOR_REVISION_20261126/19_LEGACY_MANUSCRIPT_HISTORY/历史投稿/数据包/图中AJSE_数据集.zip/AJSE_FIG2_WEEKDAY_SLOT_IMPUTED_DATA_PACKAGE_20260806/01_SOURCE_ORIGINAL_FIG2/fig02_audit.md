# Figure 2 audit

Frozen complete-grid, attrition, coverage, and formal test-origin quality data were derived. Origin-level confidence is absent and was not substituted.
