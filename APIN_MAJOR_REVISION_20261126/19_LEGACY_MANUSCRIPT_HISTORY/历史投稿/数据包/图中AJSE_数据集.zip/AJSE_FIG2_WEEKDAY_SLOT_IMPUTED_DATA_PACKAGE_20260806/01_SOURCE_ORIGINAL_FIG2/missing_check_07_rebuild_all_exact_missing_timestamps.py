#!/usr/bin/env python
"""
Reconstruct every exact missing/unreturned 15-min node-time key for AJSE Fig. 2.

Run locally against the frozen Phase2A data directory. This script does not
interpolate values. It only enumerates theoretical keys that are absent from
the observed/deduplicated source.

Expected frozen grid:
- 51 nodes
- 2025-12-08 14:00 to 2026-02-28 23:45, inclusive
- 15-min interval
- expected theoretical rows = 403,512
- expected missing/unreturned rows = 160,755

Recommended input:
01_DATA_PIPELINE/panels/deduplicated_15min_observations.parquet

Alternative input:
package_extracted/04_panels/panel_15min_observed_only.csv.gz
"""

from __future__ import annotations

import argparse
from pathlib import Path
import pandas as pd


GRID_START = pd.Timestamp("2025-12-08 14:00:00")
GRID_END = pd.Timestamp("2026-02-28 23:45:00")
EXPECTED_NODES = 51
EXPECTED_THEORETICAL = 403_512
EXPECTED_MISSING = 160_755


def find_column(columns, candidates, label):
    lookup = {str(c).lower(): c for c in columns}
    for candidate in candidates:
        if candidate.lower() in lookup:
            return lookup[candidate.lower()]
    raise KeyError(
        f"Cannot identify {label} column. Available columns: {list(columns)}"
    )


def contiguous_intervals(missing):
    out = []
    for node_id, group in missing.groupby("node_id", sort=True):
        times = sorted(pd.to_datetime(group["timestamp_local"]).tolist())
        if not times:
            continue
        start = prev = times[0]
        for current in times[1:] + [None]:
            if current is not None and current - prev == pd.Timedelta(minutes=15):
                prev = current
                continue
            slots = int((prev - start) / pd.Timedelta(minutes=15)) + 1
            out.append(
                {
                    "node_id": node_id,
                    "start_timestamp_local": start,
                    "end_timestamp_local": prev,
                    "missing_15min_slots": slots,
                    "duration_hours": slots * 0.25,
                }
            )
            if current is not None:
                start = prev = current
    return pd.DataFrame(out)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--observed", required=True, help="Parquet or CSV/CSV.GZ observed file")
    parser.add_argument("--nodes", required=True, help="nodes.csv containing the 51 frozen node IDs")
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    observed_path = Path(args.observed)
    nodes_path = Path(args.nodes)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if observed_path.suffix.lower() == ".parquet":
        observed = pd.read_parquet(observed_path)
    else:
        observed = pd.read_csv(observed_path)

    nodes = pd.read_csv(nodes_path)

    observed_node_col = find_column(
        observed.columns,
        ["node_id", "node", "virtual_node_id", "point_id"],
        "observed node ID",
    )
    observed_time_col = find_column(
        observed.columns,
        ["timestamp", "timestamp_local", "datetime", "time"],
        "observed timestamp",
    )
    nodes_node_col = find_column(
        nodes.columns,
        ["node_id", "node", "virtual_node_id", "point_id"],
        "nodes node ID",
    )

    node_ids = (
        nodes[nodes_node_col].astype(str).drop_duplicates().sort_values().tolist()
    )
    if len(node_ids) != EXPECTED_NODES:
        raise ValueError(f"Expected 51 nodes, found {len(node_ids)}")

    obs = observed[[observed_node_col, observed_time_col]].copy()
    obs.columns = ["node_id", "timestamp_local"]
    obs["node_id"] = obs["node_id"].astype(str)
    obs["timestamp_local"] = pd.to_datetime(obs["timestamp_local"], errors="raise")
    # Remove timezone information only after converting to Malaysia local time if needed.
    if getattr(obs["timestamp_local"].dt, "tz", None) is not None:
        obs["timestamp_local"] = (
            obs["timestamp_local"]
            .dt.tz_convert("Asia/Kuala_Lumpur")
            .dt.tz_localize(None)
        )

    obs = obs[
        (obs["timestamp_local"] >= GRID_START)
        & (obs["timestamp_local"] <= GRID_END)
        & (obs["node_id"].isin(node_ids))
    ].drop_duplicates(["node_id", "timestamp_local"])

    timestamps = pd.date_range(GRID_START, GRID_END, freq="15min")
    theoretical = pd.MultiIndex.from_product(
        [node_ids, timestamps], names=["node_id", "timestamp_local"]
    ).to_frame(index=False)

    if len(theoretical) != EXPECTED_THEORETICAL:
        raise AssertionError(
            f"Theoretical count mismatch: {len(theoretical):,} "
            f"!= {EXPECTED_THEORETICAL:,}"
        )

    merged = theoretical.merge(
        obs.assign(observed_flag=True),
        on=["node_id", "timestamp_local"],
        how="left",
        validate="one_to_one",
    )
    missing = merged[merged["observed_flag"].isna()][
        ["node_id", "timestamp_local"]
    ].copy()

    missing["date"] = missing["timestamp_local"].dt.date
    missing["time_local"] = missing["timestamp_local"].dt.strftime("%H:%M")

    missing.to_csv(out_dir / "all_exact_missing_node_timestamps.csv", index=False)

    intervals = contiguous_intervals(missing)
    intervals.to_csv(out_dir / "all_missing_intervals_by_node.csv", index=False)

    by_date = (
        missing.groupby("date", as_index=False)
        .agg(missing_unreturned_slots=("timestamp_local", "size"),
             affected_nodes=("node_id", "nunique"))
    )
    by_date.to_csv(out_dir / "missing_summary_by_date.csv", index=False)

    by_node_date = (
        missing.groupby(["date", "node_id"], as_index=False)
        .agg(missing_unreturned_slots=("timestamp_local", "size"))
    )
    by_node_date.to_csv(out_dir / "missing_summary_by_node_date.csv", index=False)

    print(f"Theoretical keys: {len(theoretical):,}")
    print(f"Observed unique keys inside grid: {len(obs):,}")
    print(f"Missing/unreturned keys: {len(missing):,}")
    if len(missing) != EXPECTED_MISSING:
        print(
            "WARNING: missing count differs from the frozen Fig. 2 count. "
            "Do not overwrite the frozen experiment until the source/version "
            "difference is investigated."
        )


if __name__ == "__main__":
    main()
