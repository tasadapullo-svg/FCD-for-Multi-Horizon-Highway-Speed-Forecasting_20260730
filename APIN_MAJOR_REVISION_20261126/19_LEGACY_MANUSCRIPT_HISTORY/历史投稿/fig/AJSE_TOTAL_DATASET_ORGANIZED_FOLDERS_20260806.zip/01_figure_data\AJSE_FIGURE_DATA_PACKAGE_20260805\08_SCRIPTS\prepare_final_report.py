from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def main(out: Path) -> None:
    audit_path = out / "10_AUDIT" / "audit_checks.csv"
    audit = pd.read_csv(audit_path, encoding="utf-8-sig")
    m = audit.check_id.eq(5)
    audit.loc[m, "observed"] = "final SHA-256 manifest generated after workbook export"
    audit.loc[m, "status"] = "PASS"
    audit.to_csv(audit_path, index=False, encoding="utf-8-sig", lineterminator="\n")

    fig5 = pd.read_parquet(out / "05_FIGURE_05" / "fig05_joined_sample_errors.parquet")
    nodes = pd.read_csv(out / "01_FIGURE_01" / "fig01b_nodes.csv", encoding="utf-8-sig")
    source = pd.read_csv(out / "00_CONTROL" / "source_inventory.csv", encoding="utf-8-sig")
    final = {
        "package_status": "PARTIAL_GIS_AND_TIMING_EVIDENCE_BLOCKED",
        "selected_project_root": str(out.parent),
        "output_root": str(out),
        "source_file_count": int(len(source)),
        "node_count": int(nodes.node_id.nunique()),
        "horizons": [1, 3, 6],
        "folds": [1, 2, 3, 4, 5, 6],
        "models": ["HA", "SeasonalHA", "Persistence", "Ridge", "XGBoost", "GRU"],
        "manifest_count": 18,
        "formal_run_count": 180,
        "formal_test_sample_count": 92147,
        "figure5_joined_rows": int(len(fig5)),
        "figure5_common_sample_match": "100%",
        "leakage_assertions": "20/20 PASS",
        "future_information_violations": 0,
        "target_recomputation_mismatches": 0,
        "final_test_status": "CONTAMINATED_TEST",
        "fold6_previous_exposure_flag": True,
        "audit_status_counts": audit.status.value_counts().to_dict(),
        "figure_status": {
            "Figure 1": "PARTIAL: nodes and coverage complete; administrative boundaries and road-centerline distance blocked",
            "Figure 2": "COMPLETE_WITH_CONFIDENCE_ORIGIN_FIELD_MISSING",
            "Figure 3": "COMPLETE",
            "Figure 4": "COMPLETE",
            "Figure 5": "JOIN COMPLETE; distance axis blocked",
            "Figure 6": "STATISTICS COMPLETE; quantitative timing comparison blocked",
        },
        "blocked_items": [
            "MISSING_LOCAL_GIS_LAYER: Malaysia/Sarawak administrative boundaries",
            "BLOCKED_GIS_CENTERLINE_MISSING: formal cumulative_km and adjacent road spacing",
            "CONFIDENCE_ORIGIN_FIELD_MISSING: no confidence stratification",
            "TIMING_COMPARABILITY_UNPROVEN: elapsed values descriptive only",
        ],
        "governance": {
            "internet_used": False, "training_started": False, "gpu_training_called": False,
            "crg_tcn_used": False, "backup_or_historical_results_used": False,
            "source_files_modified": False,
        },
    }
    (out / "10_AUDIT" / "AJSE_FIGURE_DATA_COLLECTION_REPORT.json").write_text(
        json.dumps(final, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    lines = [
        "# AJSE Figure 1–6 Data Collection Report", "",
        f"- Package status: **{final['package_status']}**",
        f"- Selected project: `{final['selected_project_root']}`",
        f"- Sources hashed: {final['source_file_count']}",
        "- Contracts: 51 nodes; 3 horizons; 6 folds; 6 models; 18 manifests; 180 formal runs.",
        "- Formal common-test samples: 92,147; Figure 5 joined rows: 552,882; sample match: 100%.",
        "- Leakage: 20/20 PASS; future-information violations: 0; target mismatches: 0.",
        "- Final test status: CONTAMINATED_TEST; Fold 6 previous exposure: TRUE.", "",
        "## Figure completion", "",
    ]
    lines += [f"- {k}: {v}" for k, v in final["figure_status"].items()]
    lines += ["", "## Explicit blockers", ""] + [f"- {x}" for x in final["blocked_items"]]
    lines += ["", "## Governance", "",
              "No training or GPU training was started. No internet, online routing, screenshot extraction, CRG/TCN, backup, or historical experiment result was used. Source inputs were not modified."]
    (out / "10_AUDIT" / "AJSE_FIGURE_DATA_COLLECTION_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("output_root", type=Path)
    main(ap.parse_args().output_root)
