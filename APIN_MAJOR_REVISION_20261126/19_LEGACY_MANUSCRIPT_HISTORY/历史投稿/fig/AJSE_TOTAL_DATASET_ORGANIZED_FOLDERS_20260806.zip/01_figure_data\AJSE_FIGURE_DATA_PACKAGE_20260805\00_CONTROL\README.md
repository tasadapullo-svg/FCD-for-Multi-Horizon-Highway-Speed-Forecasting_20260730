# AJSE Figure 1–6 formal drawing-data package

Selected project: `E:\2026_project\01_AJSE_稀疏FCD滚动预测_Phase2A_20260730`

Status: **PARTIAL — data package usable, with explicit blockers**.

Available: 51-node coordinates, node-day coverage, complete-grid state slice, attrition, origin quality, workflow/folds, all benchmark metrics, 100% common-test Figure 5 join, and Figure 6 statistical evidence.

Blocked: formal road-centerline distance and local administrative boundaries; quantitative cross-model timing comparison. No CRG/TCN, historical, backup, online, or screenshot-derived data were used. No training was started.
