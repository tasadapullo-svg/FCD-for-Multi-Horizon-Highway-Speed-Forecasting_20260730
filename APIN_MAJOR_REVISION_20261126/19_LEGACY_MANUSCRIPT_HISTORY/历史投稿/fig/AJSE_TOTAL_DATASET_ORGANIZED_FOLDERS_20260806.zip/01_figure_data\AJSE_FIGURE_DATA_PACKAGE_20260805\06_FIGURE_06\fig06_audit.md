# Figure 6 audit

Fold-level primary inference and clustered day×spatial-block bootstrap evidence remain separate. No Holm-adjusted comparison is significant. Run elapsed values are retained as raw evidence but are not quantitatively comparable because the required environment and timing-equivalence evidence is incomplete.
