import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const projectRoot = process.argv[2];
const outputRoot = process.argv[3];
if (!projectRoot || !outputRoot) throw new Error("Usage: node build_master_workbook.mjs <projectRoot> <outputRoot>");

function parseCsv(text) {
  text = text.replace(/^\uFEFF/, "");
  const rows = [];
  let row = [], field = "", quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (c === '"') quoted = false;
      else field += c;
    } else {
      if (c === '"') quoted = true;
      else if (c === ',') { row.push(field); field = ""; }
      else if (c === '\n') { row.push(field.replace(/\r$/, "")); rows.push(row); row = []; field = ""; }
      else field += c;
    }
  }
  if (field.length || row.length) { row.push(field.replace(/\r$/, "")); rows.push(row); }
  return rows.filter(r => r.some(v => v !== ""));
}

function coerce(rows) {
  if (!rows.length) return [["status"], ["EMPTY"]];
  return rows.map((r, ri) => r.map(v => {
    if (ri === 0 || v === "") return v === "" ? null : v;
    if (/^(true|false)$/i.test(v)) return v.toLowerCase() === "true";
    if (/^-?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(v) && !/^0\d+/.test(v)) return Number(v);
    return v;
  }));
}

function colName(n) {
  let s = "";
  while (n > 0) { n--; s = String.fromCharCode(65 + n % 26) + s; n = Math.floor(n / 26); }
  return s;
}

async function sha256(file) {
  const data = await fs.readFile(file);
  return crypto.createHash("sha256").update(data).digest("hex");
}

async function walk(dir) {
  const out = [];
  for (const e of await fs.readdir(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.name === "node_modules") continue;
    if (e.isDirectory()) out.push(...await walk(p));
    else if (e.isFile()) out.push(p);
  }
  return out;
}

const sheetMap = [
  ["01_SOURCE_INVENTORY", "00_CONTROL/source_inventory.csv"],
  ["02_MISSING_FILES", "00_CONTROL/missing_files.csv"],
  ["03_AUDIT_STATUS", "10_AUDIT/audit_checks.csv"],
  ["F1_NODES", "01_FIGURE_01/fig01b_nodes.csv"],
  ["F1_SPACING", "01_FIGURE_01/fig01c_node_spacing.csv"],
  ["F1_COVERAGE", "01_FIGURE_01/fig01d_node_day_coverage.csv"],
  ["F2_FUNNEL", "02_FIGURE_02/fig02b_attrition_funnel.csv"],
  ["F2_COVERAGE", "02_FIGURE_02/fig02c_node_day_coverage.csv"],
  ["F2_ORIGIN_QUALITY", "02_FIGURE_02/fig02d_origin_quality_summary.csv"],
  ["F3_WORKFLOW", "03_FIGURE_03/fig03a_workflow_nodes.csv"],
  ["F3_FOLDS", "03_FIGURE_03/fig03c_fold_timeline.csv"],
  ["F3_COUNTS", "03_FIGURE_03/fig03c_fold_horizon_sample_counts.csv"],
  ["F3_AUDIT", "03_FIGURE_03/fig03c_audit_summary.csv"],
  ["F4_MAIN_METRICS", "04_FIGURE_04/fig04a_model_horizon_summary.csv"],
  ["F4_DELTA", "04_FIGURE_04/fig04b_delta_vs_seasonalha.csv"],
  ["F4_FOLD", "04_FIGURE_04/fig04c_fold_metrics.csv"],
  ["F4_SEED", "04_FIGURE_04/fig04d_seed_run_metrics.csv"],
  ["F5_RELIABILITY", "05_FIGURE_05/fig05a_reliability_stratified_metrics.csv"],
  ["F5_NODE_FOLD", "05_FIGURE_05/fig05b_node_fold_horizon_metrics.csv"],
  ["F5_NODE_RISK", "05_FIGURE_05/fig05c_node_risk_profile.csv"],
  ["F6_FOREST", "06_FIGURE_06/fig06a_forest_plot_data.csv"],
  ["F6_COST", "06_FIGURE_06/fig06b_performance_cost_evidence.csv"],
  ["DATA_DICTIONARY", "00_CONTROL/data_dictionary.csv"],
];

const workbook = Workbook.create();
const renderRanges = new Map();
const readme = workbook.worksheets.add("00_README");
renderRanges.set("00_README", "A1:D18");
readme.showGridLines = false;
readme.getRange("A1:D1").merge();
readme.getRange("A1").values = [["AJSE Figure 1–6 Formal Drawing-Data Master"]];
readme.getRange("A1:D1").format = { fill: "#1F4E78", font: { bold: true, color: "#FFFFFF", size: 16 }, rowHeight: 30 };
readme.getRange("A3:B12").values = [
  ["Item", "Value"],
  ["Selected project", projectRoot],
  ["Package status", "PARTIAL — GIS centerline/admin boundaries and timing comparability explicitly blocked"],
  ["Formal node count", 51],
  ["Formal horizons", "H1, H3, H6"],
  ["Formal folds", "F1–F6"],
  ["Formal models", "HA, SeasonalHA, Persistence, Ridge, XGBoost, GRU"],
  ["Common-test samples", 92147],
  ["Audit PASS count", null],
  ["Audit BLOCKED count", null],
];
readme.getRange("A14:D18").values = [
  ["Use note", "Large sample-level data remain in Parquet. This workbook is an index and compact review layer.", null, null],
  ["GIS note", "No formal centerline was found in the selected AJSE project; cumulative_km is intentionally blank.", null, null],
  ["Inference note", "Fold primary inference and clustered day×spatial-block bootstrap are kept separate.", null, null],
  ["Timing note", "Elapsed times are descriptive only because comparability evidence is incomplete.", null, null],
  ["Governance", "No training, internet, screenshot extraction, CRG/TCN, backup, or historical result was used.", null, null],
];
readme.getRange("A3:B3").format = { fill: "#D9EAF7", font: { bold: true, color: "#1F1F1F" }, borders: { preset: "doubleBottom", style: "thin", color: "#7F8C8D" } };
readme.getRange("A14:A18").format = { fill: "#EAF2F8", font: { bold: true, color: "#1F4E78" } };
readme.getRange("A3:D18").format.wrapText = true;
readme.getRange("A:A").format.columnWidth = 24;
readme.getRange("B:B").format.columnWidth = 90;
readme.getRange("C:D").format.columnWidth = 3;
readme.freezePanes.freezeRows(3);

for (const [sheetName, rel] of sheetMap) {
  const text = await fs.readFile(path.join(outputRoot, rel), "utf8");
  const rows = coerce(parseCsv(text));
  const sheet = workbook.worksheets.add(sheetName);
  sheet.showGridLines = false;
  const cols = Math.max(...rows.map(r => r.length));
  for (const r of rows) while (r.length < cols) r.push(null);
  const chunk = 800;
  for (let i = 0; i < rows.length; i += chunk) {
    const part = rows.slice(i, i + chunk);
    sheet.getRangeByIndexes(i, 0, part.length, cols).values = part;
  }
  const lastCol = colName(cols);
  sheet.getRange(`A1:${lastCol}1`).format = {
    fill: "#1F4E78", font: { bold: true, color: "#FFFFFF" },
    borders: { preset: "doubleBottom", style: "thin", color: "#7F8C8D" }, wrapText: true,
  };
  sheet.getRange(`A1:${lastCol}${Math.min(rows.length, 200)}`).format.font = { name: "Calibri", size: 10 };
  sheet.freezePanes.freezeRows(1);
  if (["F1_NODES", "F1_SPACING", "F1_COVERAGE", "F2_COVERAGE", "F5_NODE_FOLD", "F5_NODE_RISK"].includes(sheetName)) sheet.freezePanes.freezeColumns(2);
  for (let c = 0; c < cols; c++) {
    const sample = rows.slice(0, Math.min(rows.length, 80)).map(r => String(r[c] ?? ""));
    const maxLen = Math.max(String(rows[0][c] ?? "").length, ...sample.map(v => v.length));
    sheet.getRange(`${colName(c+1)}:${colName(c+1)}`).format.columnWidth = Math.max(9, Math.min(42, maxLen + 2));
  }
  if (rows.length > 1) sheet.getRange(`A2:${lastCol}${rows.length}`).format.rowHeight = 18;
  renderRanges.set(sheetName, `A1:${lastCol}${Math.min(rows.length, 40)}`);
}

readme.getRange("B11").formulas = [["=COUNTIF('03_AUDIT_STATUS'!$F$2:$F$48,\"PASS\")"]];
readme.getRange("B12").formulas = [["=COUNTIF('03_AUDIT_STATUS'!$F$2:$F$48,\"BLOCKED\")"]];

const hashSheet = workbook.worksheets.add("SHA256_MANIFEST");
hashSheet.showGridLines = false;
const existing = (await walk(outputRoot)).filter(p => !p.includes(`${path.sep}09_LOGS${path.sep}temp${path.sep}`) && !p.endsWith("AJSE_FIGURE_DATA_MASTER.xlsx"));
const hashRows = [["relative_path", "size_bytes", "sha256", "manifest_stage"]];
for (const p of existing.sort()) hashRows.push([path.relative(outputRoot, p).replaceAll("\\", "/"), (await fs.stat(p)).size, await sha256(p), "pre-workbook"]);
hashSheet.getRangeByIndexes(0, 0, hashRows.length, 4).values = hashRows;
hashSheet.getRange("A1:D1").format = { fill: "#1F4E78", font: { bold: true, color: "#FFFFFF" }, borders: { preset: "doubleBottom", style: "thin", color: "#7F8C8D" } };
hashSheet.getRange("A:A").format.columnWidth = 75;
hashSheet.getRange("B:B").format.columnWidth = 15;
hashSheet.getRange("C:C").format.columnWidth = 68;
hashSheet.getRange("D:D").format.columnWidth = 18;
hashSheet.freezePanes.freezeRows(1);
renderRanges.set("SHA256_MANIFEST", `A1:D${Math.min(hashRows.length, 40)}`);

const previewDir = path.join(outputRoot, "09_LOGS", "temp", "workbook_previews");
await fs.mkdir(previewDir, { recursive: true });
const inspected = await workbook.inspect({ kind: "table", range: "00_README!A1:D18", include: "values,formulas", tableMaxRows: 18, tableMaxCols: 4, maxChars: 5000 });
await fs.writeFile(path.join(outputRoot, "09_LOGS", "workbook_key_range_inspection.ndjson"), inspected.ndjson, "utf8");
const errors = await workbook.inspect({ kind: "match", searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A", options: { useRegex: true, maxResults: 300 }, summary: "final formula error scan" });
await fs.writeFile(path.join(outputRoot, "09_LOGS", "workbook_formula_error_scan.ndjson"), errors.ndjson, "utf8");
for (const name of ["00_README", ...sheetMap.map(x => x[0]), "SHA256_MANIFEST"]) {
  const preview = await workbook.render({ sheetName: name, range: renderRanges.get(name), scale: 0.7, format: "png" });
  await fs.writeFile(path.join(previewDir, `${name}.png`), new Uint8Array(await preview.arrayBuffer()));
}
const xlsx = await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(path.join(outputRoot, "07_MASTER_WORKBOOK", "AJSE_FIGURE_DATA_MASTER.xlsx"));
await fs.writeFile(path.join(outputRoot, "09_LOGS", "workbook_build_log.json"), JSON.stringify({
  sheet_count: 25, rendered_sheet_count: 25, formula_error_scan_file: "09_LOGS/workbook_formula_error_scan.ndjson",
  output: "07_MASTER_WORKBOOK/AJSE_FIGURE_DATA_MASTER.xlsx"
}, null, 2), "utf8");
