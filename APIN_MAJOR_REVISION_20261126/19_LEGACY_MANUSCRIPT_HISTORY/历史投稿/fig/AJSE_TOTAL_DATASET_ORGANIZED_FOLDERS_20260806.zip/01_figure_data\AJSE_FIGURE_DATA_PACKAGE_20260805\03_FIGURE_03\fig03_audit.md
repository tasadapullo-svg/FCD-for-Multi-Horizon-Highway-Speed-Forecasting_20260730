# Figure 3 audit

All 18 manifests were read. One real formal test sample per fold–horizon was checked for causal history, future target timing, split containment, and target observed-count requirements. Fold 6 remains explicitly exposed and the final test status is CONTAMINATED_TEST.
