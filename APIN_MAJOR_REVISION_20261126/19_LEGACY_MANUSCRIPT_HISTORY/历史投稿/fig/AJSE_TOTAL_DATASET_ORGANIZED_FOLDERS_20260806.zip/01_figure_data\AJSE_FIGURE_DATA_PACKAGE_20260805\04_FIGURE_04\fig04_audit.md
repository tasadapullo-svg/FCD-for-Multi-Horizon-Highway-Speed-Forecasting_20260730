# Figure 4 audit

All six models and three horizons are present. Each model–horizon has six folds. Seed-level distributions are retained only for XGBoost and GRU with seeds 42, 2026, and 3407.
