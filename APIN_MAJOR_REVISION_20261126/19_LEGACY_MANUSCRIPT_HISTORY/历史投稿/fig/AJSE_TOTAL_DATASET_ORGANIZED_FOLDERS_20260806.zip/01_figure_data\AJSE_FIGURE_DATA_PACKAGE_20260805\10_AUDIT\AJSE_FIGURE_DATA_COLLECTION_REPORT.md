# AJSE Figure 1–6 Data Collection Report

- Package status: **PARTIAL_GIS_AND_TIMING_EVIDENCE_BLOCKED**
- Selected project: `E:\2026_project\01_AJSE_稀疏FCD滚动预测_Phase2A_20260730`
- Sources hashed: 219
- Contracts: 51 nodes; 3 horizons; 6 folds; 6 models; 18 manifests; 180 formal runs.
- Formal common-test samples: 92,147; Figure 5 joined rows: 552,882; sample match: 100%.
- Leakage: 20/20 PASS; future-information violations: 0; target mismatches: 0.
- Final test status: CONTAMINATED_TEST; Fold 6 previous exposure: TRUE.

## Figure completion

- Figure 1: PARTIAL: nodes and coverage complete; administrative boundaries and road-centerline distance blocked
- Figure 2: COMPLETE_WITH_CONFIDENCE_ORIGIN_FIELD_MISSING
- Figure 3: COMPLETE
- Figure 4: COMPLETE
- Figure 5: JOIN COMPLETE; distance axis blocked
- Figure 6: STATISTICS COMPLETE; quantitative timing comparison blocked

## Explicit blockers

- MISSING_LOCAL_GIS_LAYER: Malaysia/Sarawak administrative boundaries
- BLOCKED_GIS_CENTERLINE_MISSING: formal cumulative_km and adjacent road spacing
- CONFIDENCE_ORIGIN_FIELD_MISSING: no confidence stratification
- TIMING_COMPARABILITY_UNPROVEN: elapsed values descriptive only

## Governance

No training or GPU training was started. No internet, online routing, screenshot extraction, CRG/TCN, backup, or historical experiment result was used. Source inputs were not modified.
