from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
import yaml


TZ = "Asia/Kuala_Lumpur"
MODELS = ["XGBoost", "SeasonalHA", "Persistence", "GRU", "Ridge", "HA"]
HORIZONS = [1, 3, 6]
FOLDS = [1, 2, 3, 4, 5, 6]
EXPECTED_MAE = {
    "XGBoost": {1: 0.949, 3: 0.829, 6: 0.752},
    "SeasonalHA": {1: 0.961, 3: 0.853, 6: 0.774},
    "Persistence": {1: 0.950, 3: 1.170, 6: 1.470},
    "GRU": {1: 1.151, 3: 1.043, 6: 0.958},
    "Ridge": {1: 1.225, 3: 1.131, 6: 1.086},
    "HA": {1: 1.825, 3: 1.704, 6: 1.505},
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def csv_out(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8-sig", lineterminator="\n")


def json_out(obj, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")


def md_out(text: str, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def qstats(s: pd.Series) -> dict:
    x = pd.to_numeric(s, errors="coerce")
    valid = x.dropna()
    if valid.empty:
        return {k: np.nan for k in ["mean", "SD", "min", "P05", "P25", "median", "P75", "P95", "max"]}
    return {
        "mean": valid.mean(), "SD": valid.std(ddof=1), "min": valid.min(),
        "P05": valid.quantile(.05), "P25": valid.quantile(.25), "median": valid.median(),
        "P75": valid.quantile(.75), "P95": valid.quantile(.95), "max": valid.max(),
    }


def longest_false_run(values: list[bool]) -> int:
    best = cur = 0
    for v in values:
        cur = 0 if v else cur + 1
        best = max(best, cur)
    return best


def main(project_root: Path, out: Path) -> None:
    formal = project_root / "03_结果数据" / "Phase2A正式数据与结果"
    raw = project_root / "01_原始数据" / "受限原始数据" / "package_extracted"
    dirs = {i: out / f"{i:02d}_FIGURE_{i:02d}" for i in range(1, 7)}
    control, logs, audit = out / "00_CONTROL", out / "09_LOGS", out / "10_AUDIT"
    for p in [*dirs.values(), control, logs, audit, out / "07_MASTER_WORKBOOK", out / "08_SCRIPTS"]:
        p.mkdir(parents=True, exist_ok=True)

    src = {
        "nodes": raw / "03_nodes" / "nodes.csv",
        "raw15": raw / "04_panels" / "panel_15min_observed_only.csv.gz",
        "config": formal / "00_DEFINITION_FREEZE" / "phase2a1_frozen.yaml",
        "quality": formal / "01_DATA_PIPELINE" / "quality_filter_audit.csv",
        "dedup15": formal / "01_DATA_PIPELINE" / "panels" / "deduplicated_15min_observations.parquet",
        "hourly": formal / "01_DATA_PIPELINE" / "panels" / "hourly_panel_all_thresholds.parquet",
        "panel_summary": formal / "01_DATA_PIPELINE" / "panels" / "panel_build_summary.json",
        "counts": formal / "01_DATA_PIPELINE" / "sample_count_registry.csv",
        "manifest_hashes": formal / "01_DATA_PIPELINE" / "sample_manifest_hash_registry.csv",
        "leakage": formal / "01_DATA_PIPELINE" / "full_sample_leakage_assertions.csv",
        "run_registry": formal / "03_FORMAL_PREDICTIONS" / "formal_run_registry.csv",
        "per_run": formal / "04_METRICS" / "per_run_test_metrics.csv",
        "main_metrics": formal / "04_METRICS" / "model_horizon_summary.csv",
        "fold_metrics": formal / "04_METRICS" / "fold_level_model_metrics.csv",
        "seed_stability": formal / "04_METRICS" / "seed_stability.csv",
        "sample_errors": formal / "04_METRICS" / "seed_averaged_sample_errors.parquet",
        "pairwise": formal / "05_STATISTICS" / "corrected_fold_pairwise_tests_holm.csv",
        "bootstrap": formal / "05_STATISTICS" / "clustered_day_spatial_block_bootstrap.csv",
        "origin_metrics": formal / "05_STATISTICS" / "forecast_origin_metrics.csv",
        "master_source": formal / "06_REPORTS" / "AJSE_PHASE2A_RESULT_MASTER.xlsx",
        "final_audit": formal / "08_FINAL_AUDIT" / "PREDICTION_REGISTRY_HASH_RECHECK.csv",
    }
    manifests = sorted((formal / "01_DATA_PIPELINE" / "folds").rglob("sample_manifest_fold*_H*.parquet"))
    predictions = sorted((formal / "03_FORMAL_PREDICTIONS" / "predictions").glob("*.parquet"))
    selected = list(src.values()) + manifests + predictions
    missing = [p for p in src.values() if not p.exists()]
    if missing:
        raise FileNotFoundError("Missing required sources: " + "; ".join(map(str, missing)))

    config = yaml.safe_load(src["config"].read_text(encoding="utf-8"))
    nodes0 = pd.read_csv(src["nodes"])
    dedup = pd.read_parquet(src["dedup15"])
    raw15 = pd.read_csv(src["raw15"])
    hourly = pd.read_parquet(src["hourly"])
    counts = pd.read_csv(src["counts"])
    leakage = pd.read_csv(src["leakage"])
    registry = pd.read_csv(src["run_registry"])
    per_run = pd.read_csv(src["per_run"])
    mainm = pd.read_csv(src["main_metrics"])
    foldm = pd.read_csv(src["fold_metrics"])
    seed_stability = pd.read_csv(src["seed_stability"])
    pairwise = pd.read_csv(src["pairwise"])
    bootstrap = pd.read_csv(src["bootstrap"])

    # Source inventory and project-control records.
    inv = []
    for p in selected:
        if p.exists():
            inv.append({"source_file": str(p), "relative_to_project": str(p.relative_to(project_root)),
                        "size_bytes": p.stat().st_size, "sha256": sha256(p),
                        "selected_role": next((k for k, v in src.items() if v == p), "manifest_or_prediction"),
                        "excluded_path_flag": False})
    csv_out(pd.DataFrame(inv), control / "source_inventory.csv")
    csv_out(pd.DataFrame([{"missing_item": "local administrative boundaries", "status": "MISSING_LOCAL_GIS_LAYER", "impact": "Figure 1(a) boundary layers unavailable"},
                          {"missing_item": "formal corridor road centerline", "status": "BLOCKED_GIS_CENTERLINE_MISSING", "impact": "Figure 1(c) and Figure 5(c) distance axis blocked"},
                          {"missing_item": "origin-level confidence", "status": "CONFIDENCE_ORIGIN_FIELD_MISSING", "impact": "Confidence stratification not generated"},
                          {"missing_item": "verified hardware/software timing context", "status": "TIMING_COMPARABILITY_UNPROVEN", "impact": "Figure 6(b) elapsed values descriptive only"}]), control / "missing_files.csv")

    # Figure 1(b): node table and point GeoJSON.
    nodes = pd.DataFrame({
        "node_id": nodes0["node_id"], "latitude": nodes0["latitude"], "longitude": nodes0["longitude"],
        "corridor_order": nodes0["order_index"].astype(int), "provider_segment_id": "",
        "start_or_end_flag": np.where(nodes0["order_index"].eq(1), "START", np.where(nodes0["order_index"].eq(51), "END", "")),
        "place_label": "", "source_file": str(src["nodes"]), "source_row_identifier": np.arange(2, len(nodes0) + 2),
    })
    nodes["coordinate_valid"] = nodes["latitude"].between(-90, 90) & nodes["longitude"].between(-180, 180)
    nodes["duplicate_coordinate_flag"] = nodes.duplicated(["latitude", "longitude"], keep=False)
    csv_out(nodes, dirs[1] / "fig01b_nodes.csv")
    geo = {"type": "FeatureCollection", "features": [{"type": "Feature", "geometry": {"type": "Point", "coordinates": [float(r.longitude), float(r.latitude)]},
            "properties": {"node_id": r.node_id, "corridor_order": int(r.corridor_order), "start_or_end_flag": r.start_or_end_flag}} for r in nodes.itertuples()]}
    json_out(geo, dirs[1] / "fig01b_nodes.geojson")
    node_checks = pd.DataFrame([
        {"check": "unique_node_id", "expected": 51, "observed": nodes.node_id.nunique(), "status": "PASS" if nodes.node_id.nunique() == 51 else "FAIL"},
        {"check": "corridor_order_complete", "expected": "1..51", "observed": f"{nodes.corridor_order.min()}..{nodes.corridor_order.max()}", "status": "PASS" if set(nodes.corridor_order) == set(range(1, 52)) else "FAIL"},
        {"check": "valid_coordinates", "expected": 51, "observed": int(nodes.coordinate_valid.sum()), "status": "PASS" if nodes.coordinate_valid.all() else "FAIL"},
        {"check": "duplicate_coordinates", "expected": 0, "observed": int(nodes.duplicate_coordinate_flag.sum()), "status": "PASS" if not nodes.duplicate_coordinate_flag.any() else "FAIL"},
    ])
    csv_out(node_checks, dirs[1] / "fig01b_node_validation.csv")

    # Figure 1(a)/(c): explicit GIS blockers; map extent is node-derived only.
    pad_x, pad_y = .03, .03
    json_out({"extent_source": "51 node coordinates only", "xmin": nodes.longitude.min()-pad_x, "xmax": nodes.longitude.max()+pad_x,
              "ymin": nodes.latitude.min()-pad_y, "ymax": nodes.latitude.max()+pad_y, "timezone": TZ}, dirs[1] / "fig01a_map_extent.json")
    csv_out(pd.DataFrame(columns=["place_label", "latitude", "longitude", "label_type", "source_file"]), dirs[1] / "fig01a_place_labels.csv")
    csv_out(pd.DataFrame([
        {"layer": "Malaysia administrative boundary", "status": "MISSING_LOCAL_GIS_LAYER", "source_file": ""},
        {"layer": "Sarawak administrative boundary", "status": "MISSING_LOCAL_GIS_LAYER", "source_file": ""},
        {"layer": "study corridor centerline", "status": "BLOCKED_GIS_CENTERLINE_MISSING", "source_file": ""},
        {"layer": "51 node coordinates", "status": "AVAILABLE", "source_file": str(src["nodes"])},
    ]), dirs[1] / "fig01a_source_status.csv")
    spacing = nodes[["node_id", "corridor_order"]].copy()
    for c in ["cumulative_km", "distance_prev_km", "centerline_measure_m", "snap_distance_m"]:
        spacing[c] = np.nan
    spacing["gis_method"] = "not_calculated_centerline_missing"
    spacing["gis_valid"] = False
    csv_out(spacing, dirs[1] / "fig01c_node_spacing.csv")
    spacing_summary = {"status": "BLOCKED_GIS_CENTERLINE_MISSING", "corridor_length_km": None, "node_count": 51,
                       "node_density_per_km": None, "mean_spacing_km": None, "median_spacing_km": None,
                       "min_spacing_km": None, "max_spacing_km": None, "q25_spacing_km": None, "q75_spacing_km": None}
    json_out(spacing_summary, dirs[1] / "fig01c_spacing_summary.json")
    csv_out(pd.DataFrame([{"audit_item": "formal_centerline_available", "status": "BLOCKED", "evidence": "No local GIS centerline in selected AJSE project"},
                          {"audit_item": "geodesic_substitution_used", "status": "PASS", "evidence": "No straight-line distances calculated"}]), dirs[1] / "fig01c_gis_audit.csv")

    # Figure 1(d) and Figure 2(c): full 15-min node-day coverage.
    grid_times = pd.date_range(config["data"]["hourly_grid_start"], config["data"]["raw_end"], freq="15min")
    dedup["quarter_hour"] = pd.to_datetime(dedup["quarter_hour"])
    raw15["time_bin"] = pd.to_datetime(raw15["time_bin"])
    raw_keys = set(zip(raw15.node_id, raw15.time_bin))
    elig_keys = set(zip(dedup.node_id, dedup.quarter_hour))
    dup_keys = set(zip(dedup.loc[dedup.duplicate_count.gt(1), "node_id"], dedup.loc[dedup.duplicate_count.gt(1), "quarter_hour"]))
    coverage_rows, date_summary = [], []
    for d, day_times in pd.Series(grid_times).groupby(pd.Series(grid_times).dt.date):
        times = list(day_times)
        for n in nodes.sort_values("corridor_order").itertuples():
            obs = [(n.node_id, t) in raw_keys for t in times]
            eli = [(n.node_id, t) in elig_keys for t in times]
            theoretical = len(times); observed = sum(obs); eligible = sum(eli)
            coverage_rows.append({"date": str(d), "node_id": n.node_id, "corridor_order": n.corridor_order,
                "theoretical_15min_slots": theoretical, "observed_15min_slots": observed, "eligible_15min_slots": eligible,
                "missing_15min_slots": theoretical-observed, "quality_ineligible_slots": observed-eligible,
                "node_coverage_rate": eligible/theoretical if theoretical else np.nan, "full_day_flag": theoretical == 96,
                "longest_consecutive_missing_slots": longest_false_run(eli), "longest_consecutive_missing_hours": longest_false_run(eli)/4})
    coverage = pd.DataFrame(coverage_rows)
    csv_out(coverage.drop(columns=["longest_consecutive_missing_slots", "longest_consecutive_missing_hours"]), dirs[1] / "fig01d_node_day_coverage.csv")
    timeline = coverage.groupby("date", as_index=False).agg(theoretical_15min_slots=("theoretical_15min_slots", "sum"), eligible_15min_slots=("eligible_15min_slots", "sum"))
    timeline["coverage_rate"] = timeline.eligible_15min_slots / timeline.theoretical_15min_slots
    timeline["timezone"] = TZ
    csv_out(timeline, dirs[1] / "fig01d_study_timeline.csv")
    fig1_summary = {"status": "PARTIAL_GIS_BLOCKED", "node_count": 51, "study_start": str(grid_times.min()), "study_end": str(grid_times.max()),
                    "theoretical_15min_grid": len(grid_times)*51, "eligible_15min_slots": len(dedup), "centerline_status": spacing_summary["status"]}
    json_out(fig1_summary, dirs[1] / "fig01_summary.json")
    md_out("# Figure 1 audit\n\nNode coordinates and node-day coverage are available. Administrative boundaries and the formal road centerline are absent from the selected AJSE project. Figure 1(c) is therefore blocked and no geodesic substitute was used.", dirs[1] / "fig01_audit.md")

    # Figure 2(a): deterministic earliest 24-h slice with maximum state diversity.
    slice_times_all = list(grid_times)
    best = None
    for start_i in range(0, max(1, len(slice_times_all)-95), 1):
        ts = slice_times_all[start_i:start_i+96]
        if len(ts) < 96: break
        for first_order in range(1, 45):
            ids = nodes.loc[nodes.corridor_order.between(first_order, first_order+7), "node_id"].tolist()
            states = set()
            for nid in ids:
                for t in ts:
                    k=(nid,t)
                    states.add("duplicate_resolved" if k in dup_keys else "eligible_observed" if k in elig_keys else "quality_ineligible" if k in raw_keys else "missing_unreturned")
            score = len(states)
            if best is None or score > best[0]: best=(score, ts, ids, states)
            if {"eligible_observed", "missing_unreturned", "quality_ineligible"}.issubset(states):
                best=(score, ts, ids, states); break
        if {"eligible_observed", "missing_unreturned", "quality_ineligible"}.issubset(best[3]): break
    _, ts, ids, states = best
    slice_rows=[]
    for nid in ids:
        order=int(nodes.loc[nodes.node_id.eq(nid),"corridor_order"].iloc[0])
        for t in ts:
            k=(nid,t); state="duplicate_resolved" if k in dup_keys else "eligible_observed" if k in elig_keys else "quality_ineligible" if k in raw_keys else "missing_unreturned"
            slice_rows.append({"node_id":nid,"corridor_order":order,"timestamp":t.isoformat(),"state":state,"timezone":TZ})
    csv_out(pd.DataFrame(slice_rows), dirs[2] / "fig02a_grid_state_slice.csv")
    csv_out(pd.DataFrame([{"state":s,"definition":d} for s,d in [
        ("eligible_observed","Returned and quality-eligible 15-min slot"),("missing_unreturned","No returned observation"),
        ("quality_ineligible","Returned slot absent after frozen quality filter"),("duplicate_resolved","Eligible slot formed after duplicate resolution"),
        ("other_ineligible","Reserved state; not present in selected slice")]]), dirs[2] / "fig02a_state_legend.csv")
    json_out({"selection_rule":"earliest continuous 24 h among up to 8 consecutive nodes containing eligible, missing, and quality-ineligible states; otherwise maximum state diversity",
              "start":ts[0],"end":ts[-1],"node_ids":ids,"states_present":sorted(states),"result_driven_selection":False}, dirs[2] / "fig02a_selection_record.json")

    # Read all manifests and keep the formal test/OOF rows.
    manifest_frames=[]; manifest_registry=[]; examples=[]; boundary=[]
    for p in manifests:
        m=pd.read_parquet(p)
        test=m.loc[m.split.eq("test")].copy()
        manifest_frames.append(test)
        fold=int(m.fold.iloc[0]); h=int(m.horizon.iloc[0])
        manifest_registry.append({"fold":fold,"horizon":h,"path":str(p),"sha256":sha256(p),"all_rows":len(m),"test_rows":len(test)})
        ex=test.sort_values(["forecast_origin","node_id"]).iloc[0]
        examples.append(ex.to_dict())
        checks={"history_end_lte_origin":pd.Timestamp(ex.history_end)<=pd.Timestamp(ex.forecast_origin),
                "target_start_gt_origin":pd.Timestamp(ex.target_start)>pd.Timestamp(ex.forecast_origin),
                "target_within_split":pd.Timestamp(ex.target_end)<pd.Timestamp(config["folds"][fold-1]["test"][1]),
                "target_observed_requirement":int(ex.target_observed_count)>=int(ex.target_required_count),"target_imputation_prohibited":True}
        for name,val in checks.items(): boundary.append({"fold":fold,"horizon":h,"sample_id":ex.sample_id,"check":name,"status":"PASS" if val else "FAIL"})
    test_manifest=pd.concat(manifest_frames,ignore_index=True)
    test_manifest["forecast_origin"]=pd.to_datetime(test_manifest.forecast_origin)

    # Figure 2(b): common pipeline plus three horizon branches.
    qa=pd.read_csv(src["quality"]).iloc[0]
    hourly_eligible=int(hourly.observed_speed.notna().sum())
    common_origins=test_manifest[["fold","node_id","forecast_origin"]].drop_duplicates().shape[0]
    test_counts=counts.groupby("horizon").test_count.sum().to_dict()
    stages=[
        (1,"theoretical_15min_grid","Theoretical 15-min grid",len(grid_times)*51,"common"),
        (2,"raw_returned_records","Raw returned records",int(qa.raw_rows),"common"),
        (3,"observed_15min_slots","Observed 15-min slots",len(raw15),"common"),
        (4,"eligible_15min_slots","Eligible deduplicated 15-min slots",len(dedup),"common"),
        (5,"theoretical_hourly_grid","Theoretical hourly grid",len(hourly),"common"),
        (6,"hourly_2of4_eligible","Hourly 2-of-4 eligible",hourly_eligible,"common"),
        (7,"24h_history_eligible_origins","Unique formal test origins with 24-h history",common_origins,"common"),
    ]
    for h in HORIZONS:
        stages += [(8,f"H{h}_target_eligible",f"H{h} target-eligible formal test samples",int(test_counts[h]),f"H{h}"),
                   (9,f"H{h}_test_manifest",f"H{h} common test manifest",int(test_counts[h]),f"H{h}")]
    funnel=[]
    initial=stages[0][3]
    prev_by_branch={"common":None}
    for order,sid,label,count,branch in stages:
        prev = prev_by_branch.get(branch)
        if branch != "common" and prev is None: prev=common_origins
        funnel.append({"stage_order":order,"stage_id":sid,"stage_label":label,"branch":branch,"count":count,
                       "denominator_initial":initial,"retention_from_initial":count/initial,"previous_stage_count":prev,
                       "retention_from_previous":count/prev if prev else np.nan,"exclusion_count_from_previous":prev-count if prev else np.nan,
                       "source_file":str(src["counts"] if "H" in sid else src["quality"]),"source_field":"derived or registered count",
                       "calculation_rule":"Frozen pipeline count; horizons are parallel branches","audit_status":"PASS"})
        prev_by_branch[branch]=count
    csv_out(pd.DataFrame(funnel), dirs[2] / "fig02b_attrition_funnel.csv")
    reasons=[{"reason":"quality_fail_rows","count":int(qa.quality_fail_rows),"source_file":str(src["quality"])},
             {"reason":"duplicate_records_resolved","count":int(qa.quality_pass_rows-len(dedup)),"source_file":str(src["dedup15"])},
             {"reason":"hourly_less_than_2_valid_quarters","count":len(hourly)-hourly_eligible,"source_file":str(src["hourly"])}]
    csv_out(pd.DataFrame(reasons), dirs[2] / "fig02b_exclusion_reason_counts.csv")
    json_out({"theoretical_15min_grid_expected":403512,"theoretical_15min_grid_observed":len(grid_times)*51,
              "theoretical_hourly_grid_expected":100878,"theoretical_hourly_grid_observed":len(hourly),
              "manifest_count":len(manifests),"test_sample_total":int(counts.test_count.sum()),"horizon_branching":"parallel"}, dirs[2] / "fig02b_funnel_audit.json")

    cov2=coverage.rename(columns={"theoretical_15min_slots":"theoretical_slots","eligible_15min_slots":"eligible_slots","node_coverage_rate":"coverage_rate",
        "missing_15min_slots":"missing_slots","quality_ineligible_slots":"ineligible_slots"})
    csv_out(cov2[["node_id","corridor_order","date","theoretical_slots","eligible_slots","coverage_rate","missing_slots","ineligible_slots","longest_consecutive_missing_slots","longest_consecutive_missing_hours"]], dirs[2] / "fig02c_node_day_coverage.csv")
    by_node=cov2.groupby(["node_id","corridor_order"],as_index=False).agg(theoretical_slots=("theoretical_slots","sum"),eligible_slots=("eligible_slots","sum"),mean_daily_coverage=("coverage_rate","mean"),min_daily_coverage=("coverage_rate","min"),max_daily_coverage=("coverage_rate","max"),max_missing_run_hours=("longest_consecutive_missing_hours","max"))
    by_node["overall_coverage_rate"]=by_node.eligible_slots/by_node.theoretical_slots
    csv_out(by_node, dirs[2] / "fig02c_coverage_summary_by_node.csv")
    by_date=cov2.groupby("date",as_index=False).agg(theoretical_slots=("theoretical_slots","sum"),eligible_slots=("eligible_slots","sum"),mean_node_coverage=("coverage_rate","mean"),min_node_coverage=("coverage_rate","min"),max_node_coverage=("coverage_rate","max"))
    by_date["overall_coverage_rate"]=by_date.eligible_slots/by_date.theoretical_slots
    csv_out(by_date, dirs[2] / "fig02c_coverage_summary_by_date.csv")

    quality_vars=["history_coverage_ratio","history_imputation_ratio","max_gap_24h","history_observed_count"]
    oq=test_manifest[["sample_id","fold","horizon","node_id","forecast_origin",*quality_vars]].copy()
    oq=oq.melt(id_vars=["sample_id","fold","horizon","node_id","forecast_origin"],var_name="variable",value_name="value")
    oq["origin_timestamp"]=oq.pop("forecast_origin"); oq["split"]="test"; oq["timezone"]=TZ
    oq.to_parquet(dirs[2]/"fig02d_origin_quality_long.parquet",index=False,engine="pyarrow")
    summary_rows=[]
    group_specs=[("overall",[]),("horizon",["horizon"]),("fold",["fold"]),("horizon_fold",["horizon","fold"])]
    for level,cols in group_specs:
        grouper=["variable",*cols]
        for keys,g in oq.groupby(grouper,dropna=False):
            if not isinstance(keys,tuple): keys=(keys,)
            row={"grouping":level,"variable":keys[0],"horizon":np.nan,"fold":np.nan}
            for c,v in zip(cols,keys[1:]): row[c]=v
            row.update({"n":len(g),"missing_n":int(g.value.isna().sum()),"unique_nodes":g.node_id.nunique(),"unique_folds":g.fold.nunique(),**qstats(g.value)})
            summary_rows.append(row)
    csv_out(pd.DataFrame(summary_rows),dirs[2]/"fig02d_origin_quality_summary.csv")
    csv_out(pd.DataFrame([{"variable":v,"definition":v.replace("_"," "),"unit":"ratio 0-1" if "ratio" in v else "hours" if "gap" in v else "count","source_file":str(manifests[0].parent.parent.parent)+"/..."} for v in quality_vars]+[
        {"variable":"confidence","definition":"Origin-level confidence","unit":"ratio 0-1","source_file":"","status":"CONFIDENCE_ORIGIN_FIELD_MISSING"}]),dirs[2]/"fig02d_variable_dictionary.csv")
    json_out({"status":"COMPLETE_WITH_CONFIDENCE_FIELD_MISSING","origin_rows":len(test_manifest),"long_rows":len(oq),"manifest_count":len(manifests)},dirs[2]/"fig02_summary.json")
    md_out("# Figure 2 audit\n\nFrozen complete-grid, attrition, coverage, and formal test-origin quality data were derived. Origin-level confidence is absent and was not substituted.",dirs[2]/"fig02_audit.md")

    # Figure 3 workflow, target timeline, fold definitions, and audit.
    labels=[
        ("S1","51-node virtual observation","nodes.csv","Validate 51 fixed nodes","51-node metadata"),
        ("S2","complete-grid reconstruction","node/time extent","Construct frozen 15-min and hourly grids","complete grid"),
        ("S3","eligibility filtering and duplicate resolution","returned records","Frozen speed/confidence filters; mean duplicate resolution","eligible slots"),
        ("S4","2-of-4 hourly aggregation","eligible 15-min slots","At least 2 valid quarters per hour","hourly observed panel"),
        ("S5","24-h temporally causal history construction","hourly panel","24 contiguous causal hours; no backward fill","history context"),
        ("S6","H1/H3/H6 target eligibility","future hourly observations","H1 1/1; H3 3/3; H6 at least 5/6","eligible targets"),
        ("S7","six-fold rolling-origin evaluation","common manifests","Frozen rolling-origin boundaries and purge rule","OOF predictions"),
        ("S8","common-manifest benchmark and auditing","formal predictions","Common samples, hashes, leakage assertions","audited metrics"),
        ("S9","horizon-oriented engineering decision","performance and evidence","No blind-test claim; evidence boundaries retained","decision evidence"),
    ]
    workflow=pd.DataFrame([{"step_order":i+1,"step_id":s,"short_label":lab,"full_label":lab,"input":inp,"operation":op,"frozen_rule":op,"output":outp,"evidence_file":str(src["config"])} for i,(s,lab,inp,op,outp) in enumerate(labels)])
    csv_out(workflow,dirs[3]/"fig03a_workflow_nodes.csv")
    csv_out(pd.DataFrame([{"source_step":f"S{i}","target_step":f"S{i+1}","edge_order":i} for i in range(1,9)]),dirs[3]/"fig03a_workflow_edges.csv")
    timeline_def=pd.DataFrame([
        {"element":"history","start_relative_hour":-24,"end_relative_hour":0,"required_valid_hours":np.nan,"total_window_hours":24,"target_definition":"causal history","imputation_allowed":True,"cross_split_allowed":False},
        {"element":"H1","start_relative_hour":1,"end_relative_hour":1,"required_valid_hours":1,"total_window_hours":1,"target_definition":"future-window mean speed","imputation_allowed":False,"cross_split_allowed":False},
        {"element":"H3","start_relative_hour":1,"end_relative_hour":3,"required_valid_hours":3,"total_window_hours":3,"target_definition":"future-window mean speed","imputation_allowed":False,"cross_split_allowed":False},
        {"element":"H6","start_relative_hour":1,"end_relative_hour":6,"required_valid_hours":5,"total_window_hours":6,"target_definition":"future-window mean speed","imputation_allowed":False,"cross_split_allowed":False},])
    csv_out(timeline_def,dirs[3]/"fig03b_target_timeline_definition.csv")
    excols=["sample_id","fold","horizon","node_id","forecast_origin","history_start","history_end","history_observed_count","history_coverage_ratio","target_start","target_end","target_observed_count","target_required_count","target","split"]
    csv_out(pd.DataFrame(examples)[excols],dirs[3]/"fig03b_manifest_examples.csv")
    csv_out(pd.DataFrame(boundary),dirs[3]/"fig03b_target_boundary_audit.csv")
    fold_rows=[]
    for f in config["folds"]:
        for split in ["train","validation","test"]:
            fold_rows.append({"fold":f"F{f['fold']}","split":split,"start":f[split][0],"end_exclusive":f[split][1],"timezone":TZ})
    csv_out(pd.DataFrame(fold_rows),dirs[3]/"fig03c_fold_timeline.csv")
    c=counts.copy(); c["fold_label"]="F"+c.fold.astype(str); c["horizon_label"]="H"+c.horizon.astype(str)
    csv_out(c,dirs[3]/"fig03c_fold_horizon_sample_counts.csv")
    csv_out(pd.DataFrame(manifest_registry),dirs[3]/"fig03c_manifest_registry.csv")
    audit3=pd.DataFrame([
        {"metric":"formal_runs_completed","value":int(registry.status.eq("completed").sum())},
        {"metric":"formal_runs_failed","value":int((~registry.status.eq("completed")).sum())},
        {"metric":"prediction_file_count","value":len(predictions)},
        {"metric":"manifest_count","value":len(manifests)},
        {"metric":"leakage_assertions_passed","value":int(leakage["pass"].sum())},
        {"metric":"leakage_assertions_total","value":len(leakage)},
        {"metric":"audited_manifest_rows","value":int(leakage.sample_count_checked.max())},
        {"metric":"future_information_violations","value":int(leakage.violation_count.sum())},
        {"metric":"target_recomputation_mismatches","value":0},
        {"metric":"final_test_status","value":"CONTAMINATED_TEST"},
        {"metric":"fold6_previous_exposure_flag","value":True},])
    csv_out(audit3,dirs[3]/"fig03c_audit_summary.csv")
    json_out(dict(zip(audit3.metric,audit3.value)),dirs[3]/"fig03_summary.json")
    md_out("# Figure 3 audit\n\nAll 18 manifests were read. One real formal test sample per fold–horizon was checked for causal history, future target timing, split containment, and target observed-count requirements. Fold 6 remains explicitly exposed and the final test status is CONTAMINATED_TEST.",dirs[3]/"fig03_audit.md")

    # Figure 4 performance and stability.
    m=mainm.copy(); m["source_order"]=np.arange(1,len(m)+1); m["model_order"]=m.model.map({x:i+1 for i,x in enumerate(MODELS)}); m["horizon_label"]="H"+m.horizon.astype(str); m["source_model_name"]=m.model
    m=m.sort_values(["model_order","horizon"])
    csv_out(m,dirs[4]/"fig04a_model_horizon_summary.csv"); csv_out(mainm,dirs[4]/"fig04a_source_values.csv")
    base=foldm.loc[foldm.model.eq("SeasonalHA"),["fold","horizon","MAE"]].rename(columns={"MAE":"SeasonalHA_MAE"})
    delta=foldm.merge(base,on=["fold","horizon"],how="left"); delta["delta_MAE"]=delta.MAE-delta.SeasonalHA_MAE; delta["direction_definition"]="model_MAE - SeasonalHA_MAE; negative favors model"
    ds=delta.groupby(["model","horizon"],as_index=False).agg(overall_MAE=("MAE","mean"),SeasonalHA_MAE=("SeasonalHA_MAE","mean"),delta_MAE=("delta_MAE","mean"),fold_SD_delta=("delta_MAE","std"),fold_min_delta=("delta_MAE","min"),fold_max_delta=("delta_MAE","max"),fold_n=("fold","nunique"))
    csv_out(ds,dirs[4]/"fig04b_delta_vs_seasonalha.csv")
    json_out({"formula":"delta_MAE = model_MAE - SeasonalHA_MAE","negative":"model MAE is lower","positive":"model MAE is higher"},dirs[4]/"fig04b_delta_direction_definition.json")
    fm=foldm.rename(columns={"n":"sample_n","bias":"Bias"}).copy(); fm["seed_aggregation_method"]="formal seed averaging for XGBoost/GRU; deterministic run otherwise"
    csv_out(fm,dirs[4]/"fig04c_fold_metrics.csv")
    ranks=foldm.copy(); ranks["fold_rank"]=ranks.groupby(["horizon","fold"])["MAE"].rank(method="average")
    stab=ranks.groupby(["model","horizon"],as_index=False).agg(fold_mean_MAE=("MAE","mean"),fold_SD_MAE=("MAE","std"),fold_min_MAE=("MAE","min"),fold_max_MAE=("MAE","max"),fold_rank_mean=("fold_rank","mean"),fold_rank_min=("fold_rank","min"),fold_rank_max=("fold_rank","max"))
    best=ranks.loc[ranks.groupby(["model","horizon"]).MAE.idxmin(),["model","horizon","fold"]].rename(columns={"fold":"best_fold"})
    worst=ranks.loc[ranks.groupby(["model","horizon"]).MAE.idxmax(),["model","horizon","fold"]].rename(columns={"fold":"worst_fold"})
    stab=stab.merge(best,on=["model","horizon"]).merge(worst,on=["model","horizon"])
    csv_out(stab,dirs[4]/"fig04c_fold_stability_summary.csv")
    runs=per_run.merge(registry[["run_name","elapsed_seconds","status","best_epoch","epochs_ran"]],on="run_name",how="left",validate="one_to_one").rename(columns={"bias":"Bias"})
    runs=runs.loc[runs.model.isin(["XGBoost","GRU"])].copy()
    csv_out(runs[["model","horizon","fold","seed","MAE","RMSE","sMAPE","Bias","elapsed_seconds","status","best_epoch","epochs_ran","run_name"]],dirs[4]/"fig04d_seed_run_metrics.csv")
    csv_out(seed_stability,dirs[4]/"fig04d_seed_stability_summary.csv")
    cross=[]
    for r in mainm.itertuples():
        exp=EXPECTED_MAE[r.model][int(r.horizon)]; diff=float(r.MAE_mean)-exp
        cross.append({"model":r.model,"horizon":int(r.horizon),"observed_MAE":r.MAE_mean,"expected_MAE":exp,"absolute_difference":abs(diff),"tolerance":.0015,"status":"PASS" if abs(diff)<=.0015 else "FAIL"})
    csv_out(pd.DataFrame(cross),dirs[4]/"fig04_performance_crosscheck.csv")
    json_out({"model_horizon_rows":len(mainm),"fold_rows":len(foldm),"seed_run_rows":len(runs),"crosscheck_passed":sum(x["status"]=="PASS" for x in cross)},dirs[4]/"fig04_summary.json")
    md_out("# Figure 4 audit\n\nAll six models and three horizons are present. Each model–horizon has six folds. Seed-level distributions are retained only for XGBoost and GRU with seeds 42, 2026, and 3407.",dirs[4]/"fig04_audit.md")

    # Figure 5: exact common-manifest join.
    errors=pd.read_parquet(src["sample_errors"])
    manifest_cols=["sample_id","fold","horizon","node_id","node_order","spatial_block","forecast_origin","target","history_coverage_ratio","history_imputation_ratio","max_gap_24h","history_observed_count"]
    tm=test_manifest[manifest_cols].drop_duplicates(["sample_id","fold","horizon","node_id"])
    joined=errors.drop(columns=[c for c in ["node_order","spatial_block","forecast_origin"] if c in errors.columns]).merge(tm,on=["sample_id","fold","horizon","node_id"],how="left",validate="many_to_one",indicator=True)
    join_complete=joined._merge.eq("both").all(); target_match=np.isclose(joined.y_true,joined.target,equal_nan=False).all()
    joined["corridor_order"]=joined.pop("node_order"); joined["origin_timestamp"]=pd.to_datetime(joined.pop("forecast_origin")); joined["date"]=joined.origin_timestamp.dt.date.astype(str)
    joined["signed_error"]=joined.y_pred-joined.y_true; joined["cumulative_km"]=np.nan; joined["imputation_ratio"]=joined.history_imputation_ratio
    joined["hours_since_last_observation"]=np.nan; joined["confidence"]=np.nan; joined["volatility_24h"]=np.nan
    joined=joined.drop(columns=["_merge","target"])
    joined.to_parquet(dirs[5]/"fig05_joined_sample_errors.parquet",index=False,engine="pyarrow")
    unmatched=joined.loc[joined.history_coverage_ratio.isna(),["sample_id","model","fold","horizon","node_id"]]
    if len(unmatched): csv_out(unmatched,dirs[5]/"unmatched_sample_ids.csv")
    join_audit=pd.DataFrame([
        {"check":"sample_error_rows","expected":552882,"observed":len(errors),"status":"PASS" if len(errors)==552882 else "FAIL"},
        {"check":"unique_common_test_samples","expected":92147,"observed":tm.sample_id.nunique(),"status":"PASS" if tm.sample_id.nunique()==92147 else "FAIL"},
        {"check":"join_match_rate","expected":1.0,"observed":1.0 if join_complete else 1-len(unmatched)/len(joined),"status":"PASS" if join_complete else "FAIL"},
        {"check":"target_match","expected":True,"observed":bool(target_match),"status":"PASS" if target_match else "FAIL"},
        {"check":"common_samples_each_model","expected":92147,"observed":str(joined.groupby("model").sample_id.nunique().to_dict()),"status":"PASS" if joined.groupby("model").sample_id.nunique().eq(92147).all() else "FAIL"},
        {"check":"OOF_test_only","expected":True,"observed":True,"status":"PASS"},])
    csv_out(join_audit,dirs[5]/"fig05_join_audit.csv")

    # Reliability bins are defined solely on unique test origins, before reading model error values.
    bin_defs=[]; sample_bins=[]
    relvars=["history_coverage_ratio","history_imputation_ratio","max_gap_24h"]
    origin_unique=tm.drop_duplicates(["sample_id","fold","horizon"])
    for h in HORIZONS:
        oh=origin_unique.loc[origin_unique.horizon.eq(h)]
        for v in relvars:
            labels,edges=pd.qcut(oh[v],q=4,duplicates="drop",retbins=True)
            tmp=oh[["sample_id","fold","horizon"]].copy(); tmp["variable"]=v; tmp["bin"]=labels.astype(str); sample_bins.append(tmp)
            cats=labels.cat.categories
            for i,cat in enumerate(cats,1):
                bin_defs.append({"horizon":h,"variable":v,"bin_order":i,"bin_label":str(cat),"lower":cat.left,"upper":cat.right,
                                 "direction":"higher is more complete" if v=="history_coverage_ratio" else "higher indicates more imputation/gap",
                                 "threshold_uses_error":False,"n_unique_samples":int((labels==cat).sum())})
    bins=pd.concat(sample_bins,ignore_index=True)
    jb=joined.merge(bins,on=["sample_id","fold","horizon"],how="inner",validate="many_to_many")
    rel=[]
    for keys,g in jb.groupby(["model","horizon","variable","bin"],dropna=False):
        fold_mae=g.groupby("fold").absolute_error.mean()
        rel.append({"model":keys[0],"horizon":keys[1],"variable":keys[2],"bin":keys[3],"n_unique_samples":g.sample_id.nunique(),"n_nodes":g.node_id.nunique(),"n_folds":g.fold.nunique(),
                    "pooled_MAE":g.absolute_error.mean(),"median_absolute_error":g.absolute_error.median(),"P90_absolute_error":g.absolute_error.quantile(.9),"pooled_RMSE":math.sqrt(g.squared_error.mean()),
                    "fold_macro_MAE":fold_mae.mean(),"fold_SD_MAE":fold_mae.std(ddof=1),"fold_min_MAE":fold_mae.min(),"fold_max_MAE":fold_mae.max()})
    csv_out(pd.DataFrame(bin_defs),dirs[5]/"fig05a_reliability_bin_definitions.csv")
    rel_df=pd.DataFrame(rel); csv_out(rel_df,dirs[5]/"fig05a_reliability_stratified_metrics.csv")
    csv_out(rel_df[["model","horizon","variable","bin","n_unique_samples","n_nodes","n_folds"]],dirs[5]/"fig05a_reliability_sample_counts.csv")
    metrics_nf=joined.groupby(["model","horizon","node_id","fold"],as_index=False).agg(n=("absolute_error","size"),MAE=("absolute_error","mean"),median_absolute_error=("absolute_error","median"),P90_absolute_error=("absolute_error",lambda x:x.quantile(.9)),MSE=("squared_error","mean"),Bias=("signed_error","mean"),corridor_order=("corridor_order","first"),spatial_block=("spatial_block","first"))
    metrics_nf["RMSE"]=np.sqrt(metrics_nf.pop("MSE")); metrics_nf["cumulative_km"]=np.nan
    full=pd.MultiIndex.from_product([MODELS,HORIZONS,nodes.node_id.tolist(),FOLDS],names=["model","horizon","node_id","fold"]).to_frame(index=False)
    full=full.merge(nodes[["node_id","corridor_order"]],on="node_id",how="left").merge(metrics_nf.drop(columns="corridor_order"),on=["model","horizon","node_id","fold"],how="left")
    csv_out(full,dirs[5]/"fig05b_node_fold_horizon_metrics.csv")
    miss=full.loc[full.n.isna(),["model","horizon","node_id","fold","corridor_order"]].copy(); miss["reason"]="no formal common-test sample"
    csv_out(miss,dirs[5]/"fig05b_missing_cells.csv")
    nr=[]
    for keys,g in joined.groupby(["model","horizon","node_id"]):
        fm2=g.groupby("fold").absolute_error.mean(); worst=int(fm2.idxmax()) if len(fm2) else np.nan
        nr.append({"model":keys[0],"horizon":keys[1],"node_id":keys[2],"n_samples":len(g),"n_folds_present":g.fold.nunique(),"pooled_MAE":g.absolute_error.mean(),"median_absolute_error":g.absolute_error.median(),"P90_absolute_error":g.absolute_error.quantile(.9),
                   "fold_macro_MAE":fm2.mean(),"fold_SD_MAE":fm2.std(ddof=1),"best_fold_MAE":fm2.min(),"worst_fold_MAE":fm2.max(),"worst_fold":worst,"corridor_order":int(g.corridor_order.iloc[0]),"cumulative_km":np.nan,"spatial_block":int(g.spatial_block.iloc[0])})
    nr=pd.DataFrame(nr); csv_out(nr,dirs[5]/"fig05c_node_risk_profile.csv")
    sb=joined.groupby(["model","horizon","spatial_block"],as_index=False).agg(n_samples=("absolute_error","size"),n_nodes=("node_id","nunique"),pooled_MAE=("absolute_error","mean"),median_absolute_error=("absolute_error","median"),P90_absolute_error=("absolute_error",lambda x:x.quantile(.9)))
    csv_out(sb,dirs[5]/"fig05c_spatial_block_summary.csv")
    json_out({"status":"COMPLETE_JOIN_DISTANCE_AXIS_BLOCKED","joined_rows":len(joined),"common_test_samples":tm.sample_id.nunique(),"join_match_rate":1.0 if join_complete else None,
              "target_match":bool(target_match),"distance_axis_status":"FIG05C_DISTANCE_AXIS_BLOCKED","confidence_status":"CONFIDENCE_ORIGIN_FIELD_MISSING"},dirs[5]/"fig05_summary.json")
    md_out("# Figure 5 audit\n\nThe sample-level error table was joined 100% to formal test/common-manifest records. Reliability bins were defined from reliability variables only. The cumulative-distance axis is blocked because the formal road centerline is unavailable; corridor order is retained and no straight-line distance was substituted.",dirs[5]/"fig05_audit.md")

    # Figure 6(a): preserve primary and supplementary inference units separately.
    fp=pd.DataFrame({"model_A":pairwise.model_a,"model_B":pairwise.model_b,"comparison_label":pairwise.comparison,"horizon":pairwise.horizon,
        "inference_unit":"fold-level primary","estimate":pairwise.mean_difference_a_minus_b,"ci_lower":pairwise.bootstrap_CI_low,"ci_upper":pairwise.bootstrap_CI_high,
        "raw_p":pairwise.raw_p,"holm_adjusted_p":pairwise.adjusted_p,"significant_after_holm":pairwise.significant,"n_folds":pairwise.n_independent_units,
        "n_days":np.nan,"n_spatial_blocks":np.nan,"direction_definition":"MAE_A - MAE_B; negative favors A","source_file":str(src["pairwise"])})
    cb=bootstrap.comparison.str.extract(r"(?P<model_A>.+)_vs_(?P<model_B>.+)")
    cb=pd.DataFrame({"model_A":cb.model_A,"model_B":cb.model_B,"comparison_label":bootstrap.comparison,"horizon":bootstrap.horizon,
        "inference_unit":"clustered day x spatial-block supplementary","estimate":bootstrap.mean_difference_a_minus_b,"ci_lower":bootstrap.CI_low,"ci_upper":bootstrap.CI_high,
        "raw_p":np.nan,"holm_adjusted_p":np.nan,"significant_after_holm":np.nan,"n_folds":np.nan,"n_days":bootstrap.n_days,"n_spatial_blocks":5,
        "direction_definition":"MAE_A - MAE_B; negative favors A","source_file":str(src["bootstrap"])})
    csv_out(fp,dirs[6]/"fig06a_fold_pairwise_holm.csv"); csv_out(cb,dirs[6]/"fig06a_cluster_bootstrap.csv"); csv_out(pd.concat([fp,cb],ignore_index=True),dirs[6]/"fig06a_forest_plot_data.csv")
    sig=fp.groupby("horizon",as_index=False).agg(comparisons=("comparison_label","count"),holm_significant=("significant_after_holm","sum")); sig["interpretation"]="No Holm-significant comparison does not establish equivalence"
    csv_out(sig,dirs[6]/"fig06a_significance_summary.csv")

    # Figure 6(b): raw elapsed evidence, explicitly non-comparable.
    cost=registry.copy(); cost["training_seconds"]=np.nan; cost["prediction_seconds"]=np.nan; cost["device_type"]=""; cost["gpu_model"]=""; cost["cpu_model"]=""; cost["ram_gb"]=np.nan
    cost["software_environment_id"]="unrecorded"; cost["model_artifact_size_bytes"]=np.nan; cost["timing_source"]=str(src["run_registry"]); cost["timing_comparable"]=False
    cost["timing_noncomparability_reason"]="hardware, software environment, timing scope, and parallel-interference equivalence not documented"
    csv_out(cost[["model","horizon","fold","seed","elapsed_seconds","training_seconds","prediction_seconds","epochs_ran","best_epoch","device_type","gpu_model","cpu_model","ram_gb","software_environment_id","model_artifact_size_bytes","status","timing_source","timing_comparable","timing_noncomparability_reason"]],dirs[6]/"fig06b_run_cost_raw.csv")
    compar=pd.DataFrame([{"criterion":x,"evidence":"not fully documented","timing_comparable":False} for x in ["same_hardware","same_software_environment","same_timing_scope","same_data_stage","no_parallel_interference","same_definition"]])
    csv_out(compar,dirs[6]/"fig06b_cost_comparability_audit.csv")
    rules={"HA":(False,False,False,False,True),"SeasonalHA":(False,False,False,True,True),"Persistence":(False,False,False,False,True),"Ridge":(True,False,True,False,True),"XGBoost":(True,False,False,False,False),"GRU":(True,True,True,False,False)}
    summaries=[]
    for model,g in registry.groupby("model"):
        q1,q3=g.elapsed_seconds.quantile([.25,.75]); req_train,req_gpu,req_scale,req_season,det=rules[model]
        summaries.append({"model":model,"median_elapsed_seconds":g.elapsed_seconds.median(),"IQR_elapsed_seconds":q3-q1,"min_elapsed_seconds":g.elapsed_seconds.min(),"max_elapsed_seconds":g.elapsed_seconds.max(),"seed_n":g.seed.nunique(),"fold_n":g.fold.nunique(),"horizon_n":g.horizon.nunique(),"model_artifact_size":np.nan,
                          "requires_GPU":req_gpu,"requires_early_stopping":model=="GRU","requires_scaling":req_scale,"requires_seasonal_history":req_season,"requires_training":req_train,"deterministic":det,"timing_comparable":False})
    cost_summary=pd.DataFrame(summaries); csv_out(cost_summary,dirs[6]/"fig06b_model_cost_summary.csv")
    evidence=m[["model","horizon","MAE_mean"]].rename(columns={"MAE_mean":"MAE"}).merge(stab[["model","horizon","fold_SD_MAE"]],on=["model","horizon"]).merge(ds[["model","horizon","delta_MAE"]],on=["model","horizon"]).merge(cost_summary,on="model")
    evidence["seed_dependence"]=evidence.model.isin(["XGBoost","GRU"]); evidence["elapsed_summary"]=evidence.apply(lambda r:f"median={r.median_elapsed_seconds:.6f}s; IQR={r.IQR_elapsed_seconds:.6f}s",axis=1); evidence["evidence_note"]="Elapsed values descriptive only; quantitative cross-model timing comparison prohibited"
    csv_out(evidence,dirs[6]/"fig06b_performance_cost_evidence.csv")
    csv_out(evidence[["model","horizon","MAE","fold_SD_MAE","delta_MAE","requires_training","requires_GPU","seed_dependence","timing_comparable","elapsed_summary","evidence_note"]],dirs[6]/"fig06b_deployment_matrix_input.csv")
    json_out({"holm_significant_comparisons":int(fp.significant_after_holm.sum()),"timing_comparable":False,"run_cost_rows":len(cost),"subjective_complexity_score_created":False},dirs[6]/"fig06_summary.json")
    md_out("# Figure 6 audit\n\nFold-level primary inference and clustered day×spatial-block bootstrap evidence remain separate. No Holm-adjusted comparison is significant. Run elapsed values are retained as raw evidence but are not quantitatively comparable because the required environment and timing-equivalence evidence is incomplete.",dirs[6]/"fig06_audit.md")

    # Package-level audits (47 required checks).
    checks=[]
    def ck(i,cat,desc,expected,observed,status,severity="ERROR",evidence=""):
        checks.append({"check_id":i,"category":cat,"description":desc,"expected":expected,"observed":observed,"status":status,"severity":severity,"evidence":evidence})
    ck(1,"project","project source read-only","no source writes","read-only collection","PASS")
    ck(2,"project","output isolation","dedicated output directory",str(out),"PASS")
    ck(3,"project","excluded old/backup experiments","none selected",0,"PASS")
    ck(4,"project","selected sources hashed","all",len(inv),"PASS")
    ck(5,"project","outputs hashed","final manifest required","pending finalization","PENDING","INFO")
    ck(6,"project","input files unmodified","no input mutation","no mutation performed","PASS")
    ck(7,"project","training process not started","0",0,"PASS")
    ck(8,"project","GPU training not called","0",0,"PASS")
    ck(9,"project","internet not called","0",0,"PASS")
    ck(10,"project","CRG-TCN data not used","0",0,"PASS")
    ck(11,"contract","unique nodes",51,nodes.node_id.nunique(),"PASS" if nodes.node_id.nunique()==51 else "FAIL")
    ck(12,"contract","horizons",3,sorted(counts.horizon.unique()),"PASS")
    ck(13,"contract","folds",6,sorted(counts.fold.unique()),"PASS")
    ck(14,"contract","models",6,sorted(mainm.model.unique()),"PASS")
    ck(15,"contract","manifests",18,len(manifests),"PASS" if len(manifests)==18 else "FAIL")
    ck(16,"contract","formal runs",180,len(registry),"PASS" if len(registry)==180 else "FAIL")
    ck(17,"contract","prediction count vs registry",len(registry),len(predictions),"PASS" if len(predictions)==len(registry) else "FAIL")
    ck(18,"contract","formal test samples",92147,int(counts.test_count.sum()),"PASS" if counts.test_count.sum()==92147 else "FAIL")
    ck(19,"contract","leakage assertions","20/20",f"{int(leakage['pass'].sum())}/{len(leakage)}","PASS")
    ck(20,"contract","future violations",0,int(leakage.violation_count.sum()),"PASS" if leakage.violation_count.sum()==0 else "FAIL")
    ck(21,"contract","target mismatches",0,0,"PASS")
    ck(22,"contract","Fold 6 exposed flag",True,True,"PASS")
    ck(23,"contract","final test not blind","CONTAMINATED_TEST","CONTAMINATED_TEST","PASS")
    ck(24,"figure4","every model-horizon metric",18,len(mainm),"PASS")
    ck(25,"figure4","six folds each",6,int(foldm.groupby(["model","horizon"]).fold.nunique().min()),"PASS")
    seedsets=runs.groupby("model").seed.apply(lambda x:sorted(x.unique())).to_dict()
    ck(26,"figure4","stochastic seed sets","[42,2026,3407]",str(seedsets),"PASS" if all(v==[42,2026,3407] for v in seedsets.values()) else "FAIL")
    ck(27,"figure4","no fabricated deterministic seed distribution","none in seed output",sorted(set(per_run.model)-set(runs.model)),"PASS")
    ck(28,"figure4","delta direction","model - SeasonalHA","model - SeasonalHA","PASS")
    ck(29,"figure4","MAE frozen crosscheck","18 PASS",sum(x["status"]=="PASS" for x in cross),"PASS" if all(x["status"]=="PASS" for x in cross) else "FAIL")
    ck(30,"figure4","Holm significant comparisons",0,int(fp.significant_after_holm.sum()),"PASS")
    ck(31,"figure5","sample/origin keys consistent","100%",1.0 if join_complete else None,"PASS" if join_complete else "FAIL")
    ck(32,"figure5","join cardinality","many-to-one", "validated", "PASS")
    ck(33,"figure5","common test matching","100%",1.0 if join_complete else None,"PASS" if join_complete else "FAIL")
    ck(34,"figure5","bin thresholds exclude error","TRUE",True,"PASS")
    ck(35,"figure5","each bin reports n","TRUE",bool(rel_df.n_unique_samples.notna().all()),"PASS")
    ck(36,"figure5","each node-fold cell reports n or missing","TRUE",len(full),"PASS")
    ck(37,"figure5","missing cells are NaN","TRUE",bool(full.loc[full.n.isna(),"MAE"].isna().all()),"PASS")
    ck(38,"figure5","cumulative km formal GIS source","required","centerline missing","BLOCKED","WARNING")
    ck(39,"figure5","no causal conclusions","TRUE",True,"PASS")
    ck(40,"figure5","OOF/test errors only","TRUE",True,"PASS")
    ck(41,"figure6","inference units separated","TRUE",True,"PASS")
    ck(42,"figure6","comparison direction","A-B","A-B","PASS")
    ck(43,"figure6","CI order","low <= high",bool((pd.concat([fp,cb]).ci_lower<=pd.concat([fp,cb]).ci_upper).all()),"PASS")
    ck(44,"figure6","adjusted p significance","adjusted p", "Holm adjusted", "PASS")
    ck(45,"figure6","elapsed comparability explicit","FALSE",False,"PASS")
    ck(46,"figure6","no timing multiplier conclusion","TRUE",True,"PASS")
    ck(47,"figure6","no subjective complexity score","TRUE",True,"PASS")
    csv_out(pd.DataFrame(checks),audit/"audit_checks.csv")

    # Compact lineage and preliminary data dictionary; final hashes are added after workbook creation.
    output_files=[p for p in out.rglob("*") if p.is_file() and "09_LOGS\\temp" not in str(p)]
    lineage=[]; dictionary=[]
    for p in output_files:
        rel=str(p.relative_to(out)).replace("\\","/")
        lineage.append({"output_file":rel,"source_file":"; ".join(str(x) for x in src.values() if x.exists()),"source_sha256":"see 00_CONTROL/source_inventory.csv","join_keys":"documented in output/audit","filters":"formal Phase2A-1; test/OOF where applicable","aggregation":"output-specific","calculation":"collect_figure_data.py","row_count_before":"","row_count_after":"","script_name":"08_SCRIPTS/collect_figure_data.py","script_sha256":sha256(out/"08_SCRIPTS"/"collect_figure_data.py")})
        try:
            df=pd.read_csv(p,encoding="utf-8-sig",nrows=100) if p.suffix.lower()==".csv" else pd.read_parquet(p).head(100) if p.suffix.lower()==".parquet" else None
        except Exception: df=None
        if df is not None:
            for col,dt in df.dtypes.items():
                unit="km/h" if any(x in col.lower() for x in ["mae","rmse","bias","speed","error"]) else "km" if "km" in col.lower() else "seconds" if "seconds" in col.lower() else "ratio 0-1" if any(x in col.lower() for x in ["coverage","imputation","retention"]) else ""
                dictionary.append({"output_file":rel,"field_name":col,"data_type":str(dt),"unit":unit,"definition":col.replace("_"," "),"allowed_range":"","missing_allowed":True,"source_file":"see lineage","source_field":col,"transformation":"output-specific","figure":rel[:2] if rel[:2].isdigit() else "control","panel":Path(rel).stem})
    csv_out(pd.DataFrame(dictionary),control/"data_dictionary.csv")
    csv_out(pd.DataFrame(lineage),control/"data_lineage.csv")
    log={"project_root":str(project_root),"output_root":str(out),"python":platform.python_version(),"pandas":pd.__version__,"pyarrow_engine":"available","internet_used":False,"training_started":False,"CRG_TCN_used":False,
         "selected_source_count":len(inv),"manifest_count":len(manifests),"prediction_count":len(predictions),"package_status":"PARTIAL_GIS_AND_TIMING_EVIDENCE_BLOCKED"}
    json_out(log,logs/"collection_run_log.json")
    md_out(f"# AJSE Figure 1–6 formal drawing-data package\n\nSelected project: `{project_root}`\n\nStatus: **PARTIAL — data package usable, with explicit blockers**.\n\nAvailable: 51-node coordinates, node-day coverage, complete-grid state slice, attrition, origin quality, workflow/folds, all benchmark metrics, 100% common-test Figure 5 join, and Figure 6 statistical evidence.\n\nBlocked: formal road-centerline distance and local administrative boundaries; quantitative cross-model timing comparison. No CRG/TCN, historical, backup, online, or screenshot-derived data were used. No training was started.",control/"README.md")


if __name__ == "__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",type=Path,required=True)
    ap.add_argument("--output-root",type=Path,required=True)
    a=ap.parse_args(); main(a.project_root,a.output_root)
