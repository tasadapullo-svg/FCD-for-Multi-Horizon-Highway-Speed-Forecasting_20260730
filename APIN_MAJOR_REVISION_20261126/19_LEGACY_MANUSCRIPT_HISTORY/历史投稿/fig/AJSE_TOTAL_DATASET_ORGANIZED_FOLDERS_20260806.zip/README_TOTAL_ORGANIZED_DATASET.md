﻿# AJSE total organized dataset, 2026-08-06

This dataset is organized into extracted folders rather than nested zip files.

Folders:

1. 01_figure_data
2. 02_fig2_missing_check
3. 03_full_audit_paper_check
4. 04_fig2_imputed_result

Top-level manifests:

- 00_SOURCE_MANIFEST.csv: original source for each folder.
- 00_FILE_COUNTS.csv: file count and total bytes by folder.
