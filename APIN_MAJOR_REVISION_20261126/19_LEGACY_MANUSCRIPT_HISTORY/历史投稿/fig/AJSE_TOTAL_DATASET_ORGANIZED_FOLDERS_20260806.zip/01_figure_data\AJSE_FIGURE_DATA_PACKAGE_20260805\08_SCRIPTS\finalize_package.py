from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

import pandas as pd


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main(out: Path, zip_path: Path) -> None:
    inventory_path = out / "10_AUDIT" / "package_inventory.csv"
    log_path = out / "09_LOGS" / "finalization_log.json"
    manifest_path = out / "10_AUDIT" / "sha256_manifest.csv"
    def included(p: Path) -> bool:
        rel = p.relative_to(out).parts
        return p.is_file() and "node_modules" not in rel and not (len(rel) >= 2 and rel[0] == "09_LOGS" and rel[1] == "temp")

    excluded_names = {manifest_path.resolve(), inventory_path.resolve(), log_path.resolve()}
    base_files = sorted(p for p in out.rglob("*") if included(p) and p.resolve() not in excluded_names)
    inventory = pd.DataFrame([{
        "relative_path": p.relative_to(out).as_posix(), "size_bytes": p.stat().st_size,
        "extension": p.suffix.lower(), "directory": p.relative_to(out).parts[0],
    } for p in base_files])
    inventory.to_csv(inventory_path, index=False, encoding="utf-8-sig", lineterminator="\n")
    log = {
        "status": "READY_FOR_ZIP", "temporary_previews_removed": not (out / "09_LOGS" / "temp").exists(),
        "dependency_junction_removed": not (out / "node_modules").exists(),
        "source_files_modified": False, "training_started": False, "internet_used": False,
        "crg_tcn_used": False, "formal_png_tif_svg_pdf_generated": False,
    }
    log_path.write_text(json.dumps(log, indent=2), encoding="utf-8")
    files = sorted(p for p in out.rglob("*") if included(p) and p.resolve() != manifest_path.resolve())
    manifest = pd.DataFrame([{
        "relative_path": p.relative_to(out).as_posix(), "size_bytes": p.stat().st_size, "sha256": sha256(p)
    } for p in files])
    manifest.to_csv(manifest_path, index=False, encoding="utf-8-sig", lineterminator="\n")

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as zf:
        for p in sorted(x for x in out.rglob("*") if included(x)):
            zf.write(p, arcname=(Path(out.name) / p.relative_to(out)).as_posix())
    with zipfile.ZipFile(zip_path, "r") as zf:
        bad = zf.testzip()
        names = zf.namelist()
    if bad is not None:
        raise RuntimeError(f"ZIP CRC failure: {bad}")
    print(json.dumps({
        "output_file_count": len(files) + 1,
        "manifest_rows": len(manifest),
        "zip_entry_count": len(names),
        "zip_size_bytes": zip_path.stat().st_size,
        "zip_sha256": sha256(zip_path),
        "zip_test": "PASS",
    }, indent=2))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("output_root", type=Path)
    ap.add_argument("zip_path", type=Path)
    a = ap.parse_args()
    main(a.output_root, a.zip_path)
