# Figure 1 audit

Node coordinates and node-day coverage are available. Administrative boundaries and the formal road centerline are absent from the selected AJSE project. Figure 1(c) is therefore blocked and no geodesic substitute was used.
