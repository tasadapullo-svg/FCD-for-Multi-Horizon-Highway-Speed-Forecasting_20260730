# Figure 5 audit

The sample-level error table was joined 100% to formal test/common-manifest records. Reliability bins were defined from reliability variables only. The cumulative-distance axis is blocked because the formal road centerline is unavailable; corridor order is retained and no straight-line distance was substituted.
