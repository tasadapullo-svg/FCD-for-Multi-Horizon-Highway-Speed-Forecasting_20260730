# Figure 4 support status

**PASS for plotted values.**

The package contains the exact model×horizon fold MAE, fold means/SDs, ΔMAE relative to SeasonalHA, and XGBoost/GRU seed-level MAE values used by the four current panels. The original complete-data workbook and file checksums are retained.
