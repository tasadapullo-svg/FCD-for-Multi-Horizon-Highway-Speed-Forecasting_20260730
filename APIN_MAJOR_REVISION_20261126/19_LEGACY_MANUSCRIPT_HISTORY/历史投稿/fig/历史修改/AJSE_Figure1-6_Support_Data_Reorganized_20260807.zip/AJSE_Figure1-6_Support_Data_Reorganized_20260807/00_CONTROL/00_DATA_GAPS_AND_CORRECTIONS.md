# Data gaps and corrections to check before manuscript submission

## Figure 1 — partial reproducibility of the current artwork

The uploaded formal Figure 1 archive contains the 51 node coordinates and validation, but it explicitly records that the formal road centerline/distance layer was missing at that collection stage. The current artwork additionally shows a 130-km cumulative-distance axis, full adjacent-node spacing series, weather grids, and CAMS-derived grids. The uploaded data archives do **not** contain the complete numeric spacing vector or the weather/CAMS grid coordinates used in that current artwork.

Therefore this package includes:
- formal 51-node coordinates and validation;
- the formal GIS/source-status audit;
- the spacing summary values explicitly printed on the current artwork (transcribed and labeled as such).

The complete current spacing vector and external grid coordinates should be archived separately if bit-exact Figure 1 regeneration is required.

## Figure 2 — panels (a)–(c) exact; panel (d) source retained but transformation script absent

Panels (a)–(c) are supported by the supplied daily-data workbook and exported CSV sheets. The full 15-min filled panel and imputation reference tables are included as the source basis for panel (d). However, no separate file or script defining the exact `speed anomaly` transformation used in the current heatmap was found in the supplied archives. Do not claim bit-exact regeneration of panel (d) until that transformation is archived.

## Figure 3 — use formal timeline/run definitions, not artwork text

The formal evidence files in this package give the rolling-origin timeline as:
- F1 train: 2025-12-09 to 2026-01-12; validation: 2026-01-12 to 2026-01-19; test: 2026-01-19 to 2026-01-26;
- subsequent folds roll weekly through F6 test: 2026-02-23 to 2026-03-01.

They also show **6 model families**: HA, SeasonalHA, Persistence, Ridge, XGBoost, and GRU. The 180 formal runs arise from four deterministic model runs plus three seeds each for XGBoost and GRU over 18 fold×horizon manifests:
`4 × 18 + 2 × 3 × 18 = 180`.

Accordingly, artwork wording such as `18 manifests × 10 models` should not be used; `18 manifests × 10 run instances per manifest` or `180 formal runs across 6 model families` is accurate.

The supplied colored Figure 3 alternate also contains fold dates that do not match the formal timeline. The formal CSV files are authoritative.

## Figure 5 — spatial distance limitation retained

The Figure 5 audit states that a verified corridor-distance mapping was unavailable in the formal package. Node order is verified, but `corridor_km` is missing. The current Figure 5 correctly uses formal node order rather than claiming a verified distance coordinate.

## Figure 6 — inferential boundary

The Figure 6 audit reports zero Holm-significant prespecified pairwise comparisons at the fold level. Descriptive MAE ranking should therefore not be written as universal statistical superiority. Supplementary clustered bootstrap results are retained as supplementary evidence.
