# AJSE Figures 1–6 supporting-data package — reorganized 2026-08-07

This package reorganizes the supporting data for the **current Figure 1–Figure 6 set** shown in the supplied artwork.

## Figure mapping used in this package

1. **Figure 1** — study corridor, 51 FCD nodes, and node-spacing summary.
2. **Figure 2** — daily availability, missing records, observed/expected records, and spatiotemporal speed-anomaly panel.
3. **Figure 3** — GATE-FCD framework / rolling-origin design. Two supplied artwork variants are retained; the black/white framework is stored as the current candidate and the colored workflow as an alternate.
4. **Figure 4** — multi-horizon predictive performance, ΔMAE vs SeasonalHA, fold variation, and seed variability.
5. **Figure 5** — reliability-conditioned errors, node×fold XGBoost MAE, unique sample counts, and node-order risk profile.
6. **Figure 6** — statistical evidence boundaries (fold-level primary inference plus supplementary clustered bootstrap evidence).

## Package policy

- No model was retrained.
- No formal prediction/result file was modified.
- Existing evidence files were copied and renamed into figure-specific folders.
- Small CSV index/summary files created here are explicitly labeled as package metadata or artwork transcription.
- Redundant very large Figure 5 CSV duplicates were omitted where an equivalent Parquet file is included; the compact plotted metric tables and complete workbook are retained.

## Important evidence boundaries

See `00_DATA_GAPS_AND_CORRECTIONS.md` before using the figures in the manuscript. The formal CSV/Parquet/XLSX evidence is authoritative when it conflicts with artwork text.
