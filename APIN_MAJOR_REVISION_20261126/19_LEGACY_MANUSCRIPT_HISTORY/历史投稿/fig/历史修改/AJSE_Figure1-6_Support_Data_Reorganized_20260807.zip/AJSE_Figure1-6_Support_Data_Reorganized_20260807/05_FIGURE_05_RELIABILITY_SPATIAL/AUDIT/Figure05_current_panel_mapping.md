# Figure 5 current panel mapping

- Current panel (a): `DATA/FIG05A/Fig05a_reliability_stratified_metrics.csv` plus bin definitions/fold metrics.
- Current panel (b): `DATA/FIG05B/Fig05b_XGBoost_node_fold_metrics.csv`.
- Current panel (c): `DATA/FIG05B/Fig05b_node_fold_sample_count.csv`.
- Current panel (d): `DATA/FIG05C/Fig05c_XGBoost_node_risk_profile.csv`.

Reproduction-level sample errors and unique test origins are included as Parquet files. See `FINAL_STATUS.md` and `Fig05_detailed_validation_report.md` for limitations.
