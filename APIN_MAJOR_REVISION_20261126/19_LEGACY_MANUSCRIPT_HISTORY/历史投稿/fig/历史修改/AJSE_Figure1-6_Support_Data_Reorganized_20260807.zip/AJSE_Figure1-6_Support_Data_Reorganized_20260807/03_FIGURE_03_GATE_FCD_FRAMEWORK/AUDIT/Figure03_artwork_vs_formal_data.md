# Figure 3 artwork versus formal evidence

Use `fig03c_fold_timeline.csv`, `fig03c_manifest_registry.csv`, `fig03b_target_timeline_definition.csv`, `fig03c_audit_summary.csv`, and `formal_run_design_manifest_180.csv` as authoritative evidence.

Key formal values:
- 6 rolling-origin folds × 3 horizons = 18 common manifests.
- 180 formal runs completed, 0 failed.
- 20/20 leakage assertions passed.
- Future-information violations = 0.
- Target recomputation mismatches = 0.
- H1 target: 1/1 future hour; H3: 3/3; H6: at least 5/6.
- 24-h causal history.

The supplied artwork variants contain text/date details that should be reconciled to these formal files before submission.
