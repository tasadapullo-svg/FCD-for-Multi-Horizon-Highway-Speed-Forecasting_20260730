# Figure 6 support status

**PASS_WITH_LIMITATIONS.**

The current forest plot is directly supported by fold-paired Holm results, supplementary day×spatial-block bootstrap results, and the forest-plot data table. The Figure 6 package also retains model performance, deployment-selection evidence, runtime-comparability audit, and the 180-run design manifest for traceability.

Interpretation boundary: zero prespecified fold-level pairwise comparisons are Holm-significant; descriptive rankings must not be presented as universal inferential superiority.
