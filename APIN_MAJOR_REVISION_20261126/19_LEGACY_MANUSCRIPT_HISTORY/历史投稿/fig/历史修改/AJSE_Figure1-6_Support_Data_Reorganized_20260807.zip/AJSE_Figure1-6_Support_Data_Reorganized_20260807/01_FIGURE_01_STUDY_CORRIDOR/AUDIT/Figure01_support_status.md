# Figure 1 support status

**PARTIAL for bit-exact regeneration.**

- 51-node coordinates: available and validated.
- Current artwork summary values: transcribed into a dedicated CSV.
- Full current adjacent-node spacing vector: not found in uploaded archives.
- Formal centerline/distance layer: archived source audit says unavailable at the earlier evidence collection stage.
- Weather/CAMS grid coordinates shown in current artwork: not found in uploaded archives.
