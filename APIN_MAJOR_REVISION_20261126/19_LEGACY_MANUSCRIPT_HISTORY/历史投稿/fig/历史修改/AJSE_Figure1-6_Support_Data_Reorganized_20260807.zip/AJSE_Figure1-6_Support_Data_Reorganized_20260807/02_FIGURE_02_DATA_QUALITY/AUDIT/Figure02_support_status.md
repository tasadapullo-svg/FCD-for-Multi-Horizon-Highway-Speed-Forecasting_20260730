# Figure 2 support status

- Panels (a), (b), and (c): **exact support available** in `Figure02_daily_data_master.xlsx` and exported CSV sheets.
- Daily-data QA in the workbook: PASS for 83 rows, constant expected records = 1224/day, 51 nodes, and observed+missing accounting.
- Panel (d): the full 15-min filled source panel and imputation references are included. The exact speed-anomaly transformation/script is not separately archived in the uploaded sources.
