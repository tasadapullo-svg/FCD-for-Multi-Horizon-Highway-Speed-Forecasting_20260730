# Phase 17 Stratified Evaluation

## Data and Thresholds

- Predictions: locked Phase 13 TCN test predictions.
- Reliability: historical observed ratio (`1 - missing_mask`), rank-tertile bins. This avoids degenerate empty middle strata when numeric tertile cut points are tied.
- Coverage: historical `coverage_ratio_24h`, rank-tertile bins.
- Volatility: historical `volatility_tti_6h`, rank-tertile bins.
- Traffic state: `free_flow_speed` is unavailable in the model-ready panel, so the documented speed-tertile fallback is used with rank-tertile bins: low=degraded, middle=moderate, high=free-flow.
- Train-set numeric tertile values are recorded in `threshold_values`; assignment uses equal-frequency rank bins to retain all strata.
- Small strata are retained and marked in the detailed CSV warning column.

## Direct Answers

- Are low-reliability samples harder to predict? **No** in the pooled observed results: `low` mean MAE=0.999247; `high` mean MAE=1.321617.
- Does low coverage increase error? **No** in the pooled observed results: `low` mean MAE=0.968570; `high` mean MAE=1.300538.
- Does high volatility increase error? **Yes** in the pooled observed results: `high` mean MAE=1.546200; `low` mean MAE=0.609333.
- Are degraded traffic states harder than free-flow? **Yes** in the pooled observed results: `degraded` mean MAE=1.543597; `free-flow` mean MAE=0.927454.

## Mean ± Std Across Seeds

| stratification_type | stratum | horizon | test_n_mean | MAE_mean | MAE_std | RMSE_mean | relative_MAE_vs_best_stratum_percent_mean | seeds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| coverage | high | 1 | 4151.0 | 1.3871202530903404 | 0.10047774422584947 | 2.7993896001731775 | 53.176570742497475 | 5 |
| coverage | high | 3 | 3775.0 | 1.2933405831444342 | 0.037142061071845554 | 2.2120722681894365 | 61.524439100265866 | 5 |
| coverage | high | 6 | 4104.0 | 1.2211546126397266 | 0.013897739593765824 | 1.8909577190568574 | 71.39359347206637 | 5 |
| coverage | low | 1 | 4508.0 | 1.1057932537217634 | 0.10336528019613744 | 2.3381833439489346 | 21.996388421166433 | 5 |
| coverage | low | 3 | 4413.0 | 0.9443914900554325 | 0.032882864558273155 | 1.6963398983526354 | 17.869152076542115 | 5 |
| coverage | low | 6 | 4558.0 | 0.8555257978016684 | 0.03506616901362978 | 1.4020014674339314 | 20.118095138354118 | 5 |
| coverage | medium | 1 | 3606.0 | 0.9050987932328972 | 0.054867670860150985 | 2.1143358789740607 | 0.0 | 5 |
| coverage | medium | 3 | 3690.0 | 0.8028820975492318 | 0.05741462250995804 | 1.4921065259624458 | 0.0 | 5 |
| coverage | medium | 6 | 3504.0 | 0.7128236305768088 | 0.021077820070954593 | 1.156975640638931 | 0.0 | 5 |
| reliability | high | 1 | 4289.0 | 1.3974565455729546 | 0.10550704802838518 | 2.6253648135974372 | 60.7304456584219 | 5 |
| reliability | high | 3 | 4167.0 | 1.3045024136716523 | 0.03622932273074585 | 2.1865419957079935 | 75.35763213966392 | 5 |
| reliability | high | 6 | 4228.0 | 1.262892482364189 | 0.025842669812116737 | 1.924383731149255 | 89.83986082954863 | 5 |
| reliability | low | 1 | 3784.0 | 1.1533803376284513 | 0.0831234268608983 | 2.5366868727643355 | 32.69207797224546 | 5 |
| reliability | low | 3 | 3645.0 | 0.9722117031814304 | 0.038374016594507995 | 1.7781078609881635 | 30.594419026800402 | 5 |
| reliability | low | 6 | 3804.0 | 0.872148564536238 | 0.029725548039680305 | 1.4465943253630713 | 31.141013281739067 | 5 |
| reliability | medium | 1 | 4192.0 | 0.8703616615470129 | 0.07663563193484797 | 2.1503004940414105 | 0.0 | 5 |
| reliability | medium | 3 | 4066.0 | 0.7459473859014853 | 0.05382502669444964 | 1.3972743020498357 | 0.0 | 5 |
| reliability | medium | 6 | 4134.0 | 0.6656208425890033 | 0.017445888036902068 | 1.0675618662204651 | 0.0 | 5 |
| traffic_state | degraded | 1 | 3766.0 | 1.6116210432047549 | 0.13854136707902154 | 2.5571818925477237 | 95.6709590616673 | 5 |
| traffic_state | degraded | 3 | 3688.0 | 1.5316212789614134 | 0.053302179664093126 | 2.340307092342255 | 126.30438633117888 | 5 |
| traffic_state | degraded | 6 | 3730.0 | 1.487547588808607 | 0.052242734799247854 | 2.1518194279873053 | 164.3599893249046 | 5 |
| traffic_state | free-flow | 1 | 4028.0 | 1.055202918635106 | 0.08453906836925947 | 2.772586300257012 | 28.11389428219193 | 5 |
| traffic_state | free-flow | 3 | 3940.0 | 0.8842540191030744 | 0.04284757731869685 | 1.795415766133442 | 30.51441104182849 | 5 |
| traffic_state | free-flow | 6 | 3971.0 | 0.8429053712689706 | 0.02046409490875277 | 1.3909262867064478 | 49.767550734512625 | 5 |
| traffic_state | moderate | 1 | 4471.0 | 0.8246289872024661 | 0.06577465763193259 | 1.9887382144830021 | 0.0 | 5 |
| traffic_state | moderate | 3 | 4250.0 | 0.6776506293801701 | 0.03494143965119042 | 1.234785222971522 | 0.0 | 5 |
| traffic_state | moderate | 6 | 4465.0 | 0.56284644627758 | 0.012194312411153914 | 0.8694573221222182 | 0.0 | 5 |
| volatility | high | 1 | 4110.0 | 1.7050059276311647 | 0.14082971603490513 | 2.7953272569920857 | 156.130303652522 | 5 |
| volatility | high | 3 | 3990.0 | 1.528950333272604 | 0.04950073574755006 | 2.325550173799378 | 155.92448753829535 | 5 |
| volatility | high | 6 | 4101.0 | 1.404643061613926 | 0.038516408873005635 | 2.0393575494576752 | 149.5661290786594 | 5 |
| volatility | low | 1 | 4091.0 | 0.6663111024426237 | 0.04160662758949082 | 1.8481527455410354 | 0.0 | 5 |
| volatility | low | 3 | 3978.0 | 0.5985147480991031 | 0.03601881874828254 | 1.1822430559465418 | 0.0 | 5 |
| volatility | low | 6 | 4065.0 | 0.5631730541121329 | 0.015062197196619574 | 0.9063610715608774 | 0.0 | 5 |
| volatility | medium | 1 | 4064.0 | 1.0514727667560728 | 0.09965773452292087 | 2.5867123899267956 | 57.93525721123664 | 5 |
| volatility | medium | 3 | 3910.0 | 0.9031181046663953 | 0.04275504742329261 | 1.7693352374019642 | 51.03896240866018 | 5 |
| volatility | medium | 6 | 4000.0 | 0.8397748643875123 | 0.023302876822411864 | 1.408178623995645 | 49.11547839917126 | 5 |

## Largest Observed Error Heterogeneity

| stratification_type | stratum | horizon | test_n_mean | MAE_mean | MAE_std | RMSE_mean | relative_MAE_vs_best_stratum_percent_mean | seeds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| traffic_state | degraded | 6 | 3730.0 | 1.487547588808607 | 0.052242734799247854 | 2.1518194279873053 | 164.3599893249046 | 5 |

Interpretation follows observed MAE differences; no stratum is assumed harder before evaluation. Findings that do not follow an expected direction are retained as observed.
