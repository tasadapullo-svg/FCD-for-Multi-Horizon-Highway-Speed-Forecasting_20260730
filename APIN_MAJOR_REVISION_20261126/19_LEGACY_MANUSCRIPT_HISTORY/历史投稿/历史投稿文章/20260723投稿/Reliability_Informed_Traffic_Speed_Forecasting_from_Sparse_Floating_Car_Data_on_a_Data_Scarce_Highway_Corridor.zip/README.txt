IJITSR Overleaf project

1. Upload all files in this folder to Overleaf.
2. The source compiles immediately with the fallback article class.
3. For journal-format submission, download the official IJITSR/Springer LaTeX package from the journal or ITS Japan submission page and add svjour3.cls plus its support files to the project root. main.tex will detect svjour3.cls automatically and switch to the smallcondensed Springer layout.
4. Compile with pdfLaTeX.
5. Verify the target definition against the frozen data-generation script before submission (endpoint speed versus future-window mean).
6. Replace the provisional funding, author-contribution, repository, and DOI statements.
7. The main paper intentionally excludes Highlights and a Graphical Abstract because they are not listed as required manuscript components in the journal guidance.
